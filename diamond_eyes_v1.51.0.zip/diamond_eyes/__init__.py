bl_info = {
    "name": "Diamond Eyes",
    "author": "Custom",
    "version": (1, 51, 0),
    "blender": (3, 0, 0),
    "location": "View3D > Sidebar (N) > Diamond Eyes (สลับ Condition Linker / Material Cleanup / Check & Rename Duplicate / UV Selection / Split by Material / Sort Debris / Replace Material ในตัว)",
    "description": "Diamond Eyes: แท็บเดียวในวิวพอร์ต สลับได้ 7 โหมด - Condition Linker (VIS Condition + Zone Link Rules + ตรวจ FDST/LOD/MLOD), Material Cleanup (ลบ Material ไม่ได้ใช้), Check & Rename Duplicate (หา FDST ที่หายไป/ขาด _, Merge/join object ซ้ำ, แก้ .NNN/LOD/MLOD), UV Selection (เทียบ/ตั้ง Active UV Map), Split by Material (เลือก Material ที่จะแยก แล้ว Merge กลับได้), Sort Debris (จัดเรียงลำดับ Sub-collection ตามชื่อ _dbr_## ไม่เปลี่ยนชื่อใด ๆ), Replace Material (แทนที่ Material ที่เลือกด้วย Material ปลายทาง ไม่ลบ Material ใด ๆ)",
    "category": "Object",
}

import bpy
import bpy.utils.previews
import os
import platform
import re
from bpy.props import (
    StringProperty, BoolProperty, PointerProperty,
    CollectionProperty, IntProperty, EnumProperty,
)
from bpy.types import PropertyGroup, Operator, Panel, UIList

# =====================================================================
# Custom icon (เพชรสี - Blender ไม่ render emoji เป็นสีในหัวข้อ Panel ได้
# เลยโหลดไฟล์ภาพเพชรจริงมาใช้เป็น icon แทน)
# =====================================================================
_icons = None


def load_icons():
    global _icons
    if _icons is not None:
        return
    _icons = bpy.utils.previews.new()
    icons_dir = os.path.join(os.path.dirname(__file__), "icons")
    diamond_path = os.path.join(icons_dir, "diamond.png")
    if os.path.isfile(diamond_path):
        _icons.load("diamond_icon", diamond_path, 'IMAGE')


def unload_icons():
    global _icons
    if _icons is not None:
        bpy.utils.previews.remove(_icons)
        _icons = None


def diamond_icon_id():
    if _icons is not None and "diamond_icon" in _icons:
        return _icons["diamond_icon"].icon_id
    return 0

# =====================================================================
# Core logic: อ่านชื่อ / เรียงลำดับ / เติม Zone ใน Condition
# =====================================================================
ZONE_PATTERN = re.compile(r'ID[-_]([A-Za-z]+)')
VIS_PATTERN = re.compile(r'VIS-([A-Za-z0-9!#@^]+)')


def get_zone(name):
    """หา Zone (ตัวอักษร) จากส่วน ID- ของชื่อ object เช่น ID-A1 -> 'A'"""
    match = ZONE_PATTERN.search(name)
    return match.group(1).upper() if match else None


def get_condition(name):
    """หาข้อความ Condition ทั้งหมดหลัง VIS- เช่น VIS-B#C -> 'B#C'"""
    match = VIS_PATTERN.search(name)
    return match.group(1) if match else None


def token_key(token):
    """
    ใช้ตัวอักษรนำหน้าจริง (ตัด ! ออก และตัดเลขต่อท้ายออกด้วย) เป็น key สำหรับเรียงลำดับ/เทียบค่า
    เช่น '!B1' -> 'B', 'A1' -> 'A' — ทำให้ B1 นับเป็น zone B ได้ถูกต้อง (ไม่ใช่ zone แยกต่างหาก)
    และ token ที่ขึ้นต้นด้วยตัวอักษรเดียวกัน (เช่น A กับ A1) จะไม่ถูกสลับตำแหน่งกันเองตอนเรียง
    (Python sort เป็น stable sort - key เท่ากันจะคงลำดับเดิมไว้)
    """
    t = token.lstrip('!').upper()
    m = re.match(r'^[A-Za-z]+', t)
    return m.group(0) if m else t


def condition_tokens(condition):
    raw_tokens = re.split(r'[#@^]', condition)
    return [token_key(t) for t in raw_tokens if t]


def zone_in_condition(zone, condition):
    return zone in condition_tokens(condition)


def normalize_condition(condition, zones_to_add=None, sort=True):
    """
    เติม zone ใน zones_to_add เข้าไปในก้อน AND (เฉพาะตัวที่ยังไม่มี) แล้วเรียงลำดับตัวอักษร
    ใหม่ถ้า sort=True (ค่าเริ่มต้น) - ถ้า sort=False จะแค่เติม zone ต่อท้ายโดยไม่จัดเรียง

    - ถ้าก้อนแรก (ก่อน # ตัวแรก) เป็น token เดี่ยว (ไม่มี @ หรือ ^)
      -> รวมทุก token เป็นก้อน AND เดียวแล้วเรียงทั้งหมด (ถ้า sort=True)
    - ถ้าก้อนแรกมี @ หรือ ^
      -> เรียงเฉพาะในก้อนนั้นแยกจากก้อน AND ที่เหลือ (zone ใหม่ผูกกับก้อน AND เสมอ)
    """
    zones_to_add = zones_to_add or []
    chunks = condition.split('#')
    head = chunks[0]
    rest = chunks[1:]

    op = '@' if '@' in head else ('^' if '^' in head else None)

    if op is None:
        all_tokens = [head] + rest
        existing = [token_key(t) for t in all_tokens]
        for z in zones_to_add:
            if z and z not in existing:
                all_tokens.append(z)
                existing.append(z)
        if sort:
            all_tokens.sort(key=token_key)
        return '#'.join(all_tokens)

    head_tokens = head.split(op)
    if sort:
        head_tokens.sort(key=token_key)
    new_head = op.join(head_tokens)

    rest_tokens = list(rest)
    existing = [token_key(t) for t in head_tokens] + [token_key(t) for t in rest_tokens]
    for z in zones_to_add:
        if z and z not in existing:
            rest_tokens.append(z)
            existing.append(z)
    if sort:
        rest_tokens.sort(key=token_key)

    if rest_tokens:
        return new_head + '#' + '#'.join(rest_tokens)
    return new_head


def parse_companions(text):
    """
    แตกข้อความที่ผู้ใช้กรอก เช่น 'I, J' หรือ 'I J' หรือ 'I#J' -> ['I','J']
    เผื่อกรอกติดกันไม่มีตัวคั่น เช่น 'IJ' ก็แตกเป็นตัวอักษรเดี่ยวให้อัตโนมัติ
    (กัน bug ที่ token ที่พิมพ์ติดกันกลายเป็น zone ปลอมตัวเดียว เช่น 'BC')
    """
    if not text:
        return []
    raw = re.split(r'[,\s#]+', text.strip())
    result = []
    for t in raw:
        t = t.strip().upper()
        if not t:
            continue
        if t.isalpha() and len(t) > 1:
            result.extend(list(t))
        else:
            result.append(t)
    return result


def build_new_name(old_name, old_condition, new_condition):
    return old_name.replace(f"VIS-{old_condition}", f"VIS-{new_condition}")


# =====================================================================
# ตรวจโครงสร้างชื่อ object ตาม convention:
# <MeshName>_FDST_ID-<Zone>(ถ้ามี)_VIS-<Condition>_LOD#/MLOD#(ถ้ามี)
# =====================================================================
FDST_TAG = "FDST"
LOD_TOKEN_PATTERN = re.compile(r'^(?:LOD\d+|MLOD)$', re.IGNORECASE)
LOD_LIKE_PATTERN = re.compile(r'^M?LOD', re.IGNORECASE)
ID_TOKEN_PATTERN = re.compile(r'^ID-[A-Za-z]+\d*$')


def validate_object_name(name):
    """
    ตรวจว่าชื่อ object เรียง tag ถูกต้องตามลำดับ (Mesh -> FDST -> ID- -> VIS- -> LOD/MLOD)
    ไม่มี tag ซ้ำ ไม่มี token แปลกปลอม และ Condition ใน VIS- ไม่ผิดรูปแบบ (## ซ้อน, ขึ้น/ลงท้ายผิด)
    คืนค่า list ข้อความ error เป็นภาษาไทย (list ว่าง = ชื่อถูกต้อง)
    เรียกเฉพาะชื่อที่มี VIS- อยู่แล้ว (ตัวที่ไม่มี VIS- เลยจะไม่ถูกเก็บเข้าตารางตั้งแต่แรก)
    """
    tokens = name.split('_')
    errors = []

    vis_indices = [i for i, t in enumerate(tokens) if t.upper().startswith('VIS-')]
    if not vis_indices:
        return errors

    if len(vis_indices) > 1:
        errors.append(f"มี VIS- ซ้ำกัน {len(vis_indices)} ครั้ง")

    fdst_indices = [i for i, t in enumerate(tokens) if t.upper() == FDST_TAG]
    if len(fdst_indices) > 1:
        errors.append(f"มี {FDST_TAG} ซ้ำกัน {len(fdst_indices)} ครั้ง")
    elif len(fdst_indices) == 0:
        errors.append(
            f"ไม่พบ tag {FDST_TAG} ในชื่อ (ต้องมี _{FDST_TAG}_ ตามด้วย ID หรือ VIS ให้ถูกต้อง "
            f"เช่น HeatingPlant_01_smokestack_Base_{FDST_TAG}_ID-A_VIS-B#C)"
        )

    id_indices = []
    for i, t in enumerate(tokens):
        up = t.upper()
        if up.startswith('ID-') or up.startswith('ID_'):
            id_indices.append(i)
            if not ID_TOKEN_PATTERN.match(t.replace('ID_', 'ID-', 1)):
                errors.append(f"รูปแบบ ID ไม่ถูกต้อง: '{t}'")
    if len(id_indices) > 1:
        errors.append(f"มี ID- ซ้ำกัน {len(id_indices)} ครั้ง")

    lod_indices = [i for i, t in enumerate(tokens) if LOD_TOKEN_PATTERN.match(t)]
    lod_like_indices = [i for i, t in enumerate(tokens) if LOD_LIKE_PATTERN.match(t)]
    if len(lod_like_indices) > 1:
        found_tokens = [tokens[i] for i in lod_like_indices]
        errors.append(
            f"มีมากกว่า 1 LOD/MLOD ในชื่อเดียวกัน ต้องเหลือแค่อันเดียว (พบ: {', '.join(found_tokens)}) "
            f"- เลือกว่าจะเอา LOD หรือ MLOD"
        )

    # LOD ต้องเป็น token สุดท้ายของชื่อเสมอ ถ้ามี token ตัวเลขล้วนโผล่ต่อท้าย LOD อีก
    # (เช่น ..._LOD0_001 ซึ่งแตกเป็น token 'LOD0' กับ '001') ถือว่าผิด ต้องเหลือแค่ LODN เท่านั้น
    for li in lod_indices:
        if li + 1 < len(tokens) and re.match(r'^\d+$', tokens[li + 1]):
            errors.append(
                f"มี token เกินต่อท้าย LOD: '{tokens[li + 1]}' "
                f"(ต้องเหลือแค่ '{tokens[li]}' เท่านั้น ไม่มีอะไรต่อท้ายอีก)"
            )

    # token แปลกปลอมที่ไม่เข้าพวกไหนเลย (เช่น 000.000, ช่องว่างจาก __ ติดกัน)
    junk = []
    for i, t in enumerate(tokens):
        if t == "":
            junk.append("(ว่าง)")
            continue
        up = t.upper()
        if up == FDST_TAG or LOD_TOKEN_PATTERN.match(t) or up.startswith('ID-') or up.startswith('ID_') or up.startswith('VIS-'):
            continue
        if LOD_LIKE_PATTERN.match(t):
            # หน้าตาเหมือนตั้งใจจะเป็น LOD/MLOD แต่รูปแบบผิด (เช่นมี .001 ติดมาจาก Blender auto-rename)
            errors.append(f"รูปแบบ LOD ผิด: '{t}' (ต้องเป็น LOD0, LOD1, LOD2, ... หรือ 'MLOD' เฉย ๆ ไม่มีเลขต่อท้ายเท่านั้น)")
            continue
        if re.match(r'^[A-Za-z0-9]+$', t):
            continue
        junk.append(t)
    if junk:
        errors.append(f"พบ token แปลกปลอม: {', '.join(junk)}")

    # ลำดับ tag ที่มีอยู่จริงต้องเป็น FDST -> ID- -> VIS- -> LOD ตามลำดับ
    order_points = []
    if fdst_indices:
        order_points.append(('FDST', fdst_indices[0]))
    if id_indices:
        order_points.append(('ID-', id_indices[0]))
    order_points.append(('VIS-', vis_indices[0]))
    if lod_indices:
        order_points.append(('LOD', lod_indices[0]))
    positions = [p[1] for p in order_points]
    if positions != sorted(positions):
        found_order = sorted(order_points, key=lambda p: p[1])
        seq = ' -> '.join(p[0] for p in found_order)
        errors.append(f"ลำดับ tag ผิด (เจอเป็น: {seq})")

    # ตรวจความถูกต้องของ Condition ใน VIS- เอง
    vis_token = tokens[vis_indices[0]]
    condition_part = vis_token[4:]
    if condition_part == "":
        errors.append("VIS- ไม่มีเงื่อนไขต่อท้าย")
    else:
        if re.search(r'[#@^]{2,}', condition_part):
            errors.append(f"เงื่อนไขมี operator ซ้อนกัน: '{condition_part}'")
        if condition_part[0] in '#@^':
            errors.append(f"เงื่อนไขขึ้นต้นด้วย operator: '{condition_part}'")
        if condition_part[-1] in '#@^!':
            errors.append(f"เงื่อนไขลงท้ายด้วย operator ผิดตำแหน่ง: '{condition_part}'")
        if not re.match(r'^[A-Za-z0-9!#@^]+$', condition_part):
            errors.append(f"เงื่อนไขมีอักขระที่ไม่รู้จัก: '{condition_part}'")

    return errors


def recompute_preview(context, reset_selection=False, verbose=False):
    """
    คำนวณ new_condition/needs_update ของทุกแถวใน scene.decalzone_items ใหม่ทั้งหมด
    โดยใช้ zone/condition ที่เก็บไว้จากการสแกนล่าสุด (ไม่ไปแตะ bpy.data.objects เลย)
    เร็วและปลอดภัยพอที่จะเรียกทุกครั้งที่ค่าในตาราง Zone Link Rules เปลี่ยน (ผ่าน update callback)
    โดยไม่ต้องกดปุ่มสแกนใหม่เอง
    """
    scene = context.scene
    link_map = {r.zone: r.companions for r in scene.decalzone_link_rules}
    rule_usage = {r.zone: 0 for r in scene.decalzone_link_rules}

    for item in scene.decalzone_items:
        zone = item.zone if item.has_zone else None
        condition = item.condition

        zones_to_add = []
        if zone and not zone_in_condition(zone, condition):
            zones_to_add.append(zone)

        lookup_zones = set(condition_tokens(condition))
        if zone:
            lookup_zones.add(zone)

        companions_applied = {}
        for lz in lookup_zones:
            comp = parse_companions(link_map.get(lz, ""))
            if comp:
                companions_applied[lz] = comp
                rule_usage[lz] = rule_usage.get(lz, 0) + 1
            zones_to_add.extend(comp)

        new_condition = normalize_condition(condition, zones_to_add=zones_to_add, sort=scene.decalzone_sort_conditions)
        needs = (new_condition != condition)

        item.new_condition = new_condition
        item.needs_update = needs
        if reset_selection:
            item.selected = needs

        if verbose and needs:
            print(f"[Decal Zone] {item.name}")
            print(f"    zone ตัวเอง = {zone!r} | condition เดิม = {condition!r}")
            print(f"    เช็ค companions จาก zone: {sorted(lookup_zones)}")
            if companions_applied:
                print(f"    companions ที่พ่วงเข้ามา: {companions_applied}")
            print(f"    -> {new_condition!r}")

    for rule in scene.decalzone_link_rules:
        rule.affected_count = rule_usage.get(rule.zone, 0)


def _on_link_rule_companions_update(self, context):
    # แก้ companions แล้ว preview รีเฟรชอัตโนมัติทันที ไม่ต้องกดสแกนใหม่เอง
    # (ไม่แตะ bpy.data.objects และไม่ clear ตาราง link_rules ที่กำลังแก้อยู่ - ปลอดภัยเรียกได้ทุก keystroke)
    if context.scene.decalzone_items:
        recompute_preview(context, reset_selection=False, verbose=False)


def _on_sort_conditions_update(self, context):
    # สลับ toggle เรียง/ไม่เรียง แล้ว preview รีเฟรชให้ทันที
    if context.scene.decalzone_items:
        recompute_preview(context, reset_selection=False, verbose=False)


# =====================================================================
# PropertyGroups
# =====================================================================
class DecalZoneItem(PropertyGroup):
    name: StringProperty(name="Object Name")
    zone: StringProperty(name="Zone")
    condition: StringProperty(name="Condition ปัจจุบัน")
    new_condition: StringProperty(name="Condition ใหม่")
    needs_update: BoolProperty(name="ต้องแก้ไข", default=False)
    selected: BoolProperty(name="เลือก", default=True)
    has_zone: BoolProperty(name="มี ID เป็นของตัวเอง", default=True)
    name_valid: BoolProperty(name="ชื่อถูกต้องตาม Convention", default=True)
    name_errors: StringProperty(name="รายละเอียด Error ของชื่อ", default="")


class ZoneLinkRule(PropertyGroup):
    zone: StringProperty(name="Zone")
    companions: StringProperty(
        name="Companions",
        default="",
        description="Zone ที่ต้องการพ่วงเพิ่มสำหรับ Zone นี้ คั่นด้วย , หรือเว้นวรรค เช่น I,J",
        update=_on_link_rule_companions_update,
    )
    affected_count: IntProperty(
        name="จำนวนที่โดนผลกระทบ",
        default=0,
        description="จำนวน object ในการสแกนล่าสุดที่ถูกพ่วงจาก companions ของ zone นี้",
    )


# =====================================================================
# Operator: สแกน Collection
# =====================================================================
class DECALZONE_OT_scan(Operator):
    bl_idname = "decalzone.scan"
    bl_label = "สแกน Condition ใน Collection"
    bl_description = "สแกน Object ทั้งหมดใน Collection ที่เลือก (รวม Sub-collection) แล้วตรวจสอบ Condition"

    def execute(self, context):
        scene = context.scene
        col = scene.decalzone_collection

        if col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection ก่อน")
            return {'CANCELLED'}

        # -------- pass 1: อ่าน zone/condition ของทุก object --------
        # object ที่ไม่มี ID- เลย (zone = None) ก็ยังเก็บไว้ ไม่ข้าม แค่ไม่มี "zone ตัวเอง"
        raw = []
        for obj in col.all_objects:
            zone = get_zone(obj.name)
            condition = get_condition(obj.name)
            if condition is None:
                continue
            raw.append((zone, obj.name, condition))

        # -------- sync ตาราง Zone Link Rules --------
        # รวม zone จาก ID- ของทุก object และ zone ทุกตัวที่ปรากฏใน Condition ด้วย
        # (กันเคส object ไม่มี ID- แต่ VIS อ้างถึง zone ที่ยังไม่เคยมีแถวในตาราง)
        #
        # ถ้าสแกน Collection เดิมซ้ำ -> คงค่าที่กรอกไว้เดิมทุกแถว (เหมือนเดิม)
        # ถ้าเปลี่ยนไปสแกน Collection อื่น -> ล้างค่าการพ่วงทั้งหมดอัตโนมัติ กันปัญหาค่าจาก
        # Collection ก่อนหน้าหลุดมาปนกับ Collection ใหม่โดยไม่ตั้งใจ (เช่นตัวอักษร zone ชื่อซ้ำกัน
        # โดยบังเอิญข้าม Collection ที่ไม่เกี่ยวข้องกัน)
        same_collection = (scene.get("_decalzone_last_col", "") == col.name)
        previous_map = {r.zone: r.companions for r in scene.decalzone_link_rules}
        old_map = previous_map if same_collection else {}
        scene["_decalzone_last_col"] = col.name

        distinct_zones = set()
        for zone, obj_name, condition in raw:
            if zone:
                distinct_zones.add(zone)
            distinct_zones.update(condition_tokens(condition))
        distinct_zones = sorted(distinct_zones)

        scene.decalzone_link_rules.clear()
        for z in distinct_zones:
            rule = scene.decalzone_link_rules.add()
            rule.zone = z
            # เขียนผ่าน ID-property ตรง ๆ (ไม่ใช้ rule.companions = ...) เพื่อไม่ให้ update callback
            # ยิง recompute_preview() ซ้ำ ๆ ระหว่างสร้างตาราง ทั้งที่ decalzone_items ยังเป็นข้อมูลรอบก่อนอยู่
            rule["companions"] = old_map.get(z, "")

        if not same_collection and any(v for v in previous_map.values()):
            print("[Decal Zone] เปลี่ยน Collection ใหม่ -> ล้างค่า Zone Link Rules เดิมทั้งหมดอัตโนมัติ")

        # -------- pass 2: ใส่ข้อมูลดิบลง decalzone_items ก่อน (ยังไม่คำนวณ new_condition) --------
        # เรียง: กลุ่มที่มี ID- (เรียงตาม zone แล้วชื่อ) มาก่อน แล้วตามด้วยกลุ่มไม่มี ID- (เรียงตามชื่อ)
        raw.sort(key=lambda x: (x[0] is None, x[0] or "", x[1]))

        scene.decalzone_items.clear()
        for zone, obj_name, condition in raw:
            item = scene.decalzone_items.add()
            item.name = obj_name
            item.zone = zone or ""
            item.condition = condition
            item.has_zone = bool(zone)

            errs = validate_object_name(obj_name)
            item.name_valid = (len(errs) == 0)
            item.name_errors = "; ".join(errs)

        # -------- pass 3: คำนวณ new_condition/needs_update จริง (ใช้ฟังก์ชันเดียวกับตอนแก้ companions สด) --------
        recompute_preview(context, reset_selection=True, verbose=True)

        n_total = len(scene.decalzone_items)
        n_needs = sum(1 for it in scene.decalzone_items if it.needs_update)
        n_no_zone = sum(1 for it in scene.decalzone_items if not it.has_zone)
        n_invalid = sum(1 for it in scene.decalzone_items if not it.name_valid)
        if n_invalid:
            print(f"[Decal Zone] พบชื่อผิดรูปแบบ {n_invalid} ชิ้น:")
            for it in scene.decalzone_items:
                if not it.name_valid:
                    print(f"    {it.name}")
                    print(f"        - {it.name_errors}")
        reset_note = " | รีเซ็ตค่าการพ่วง (เปลี่ยน Collection)" if (not same_collection and any(v for v in previous_map.values())) else ""
        invalid_note = f" | ⚠ ชื่อผิดรูปแบบ {n_invalid} ชิ้น" if n_invalid else ""
        self.report(
            {'INFO'} if n_invalid == 0 else {'WARNING'},
            f"พบ {n_total} ชิ้น (ไม่มี ID- {n_no_zone} ชิ้น) | ต้องแก้ {n_needs} ชิ้น | Zone ที่พบ: {', '.join(distinct_zones)}{reset_note}{invalid_note}",
        )
        return {'FINISHED'}


# =====================================================================
# Operator: ล้างค่าการพ่วงโซนทั้งหมดด้วยตัวเอง
# =====================================================================
class DECALZONE_OT_clear_link_rules(Operator):
    bl_idname = "decalzone.clear_link_rules"
    bl_label = "ล้างค่าการพ่วงทั้งหมด"
    bl_description = "ล้างข้อความในช่องพ่วงโซนทุกแถวให้ว่างหมด (ไม่แตะชื่อ object จนกว่าจะกด สแกน/แก้ Condition ใหม่)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        n = len(context.scene.decalzone_link_rules)
        for rule in context.scene.decalzone_link_rules:
            rule.companions = ""
        self.report({'INFO'}, f"ล้างค่าการพ่วงโซนทั้งหมดแล้ว ({n} แถว)")
        return {'FINISHED'}


# =====================================================================
# Operator: คัดลอกชื่อ Object ไปยัง Clipboard (ใช้ร่วมกันทุก List ในทุกแท็บ)
# =====================================================================
class DIAMONDEYES_OT_copy_name(Operator):
    bl_idname = "diamondeyes.copy_name"
    bl_label = "Copy ชื่อ"
    bl_description = "คัดลอกชื่อ Object นี้ไปยัง Clipboard เอาไปหาใน Outliner ได้เลย"

    name_to_copy: StringProperty()

    def execute(self, context):
        context.window_manager.clipboard = self.name_to_copy
        self.report({'INFO'}, f"คัดลอกแล้ว: {self.name_to_copy}")
        return {'FINISHED'}


# =====================================================================
# Operator: คัดลอกข้อมูล Version/Diagnostic (เผื่อแจ้งปัญหา หรือเช็คว่าเป็นเวอร์ชันล่าสุดไหม)
# =====================================================================
class DIAMONDEYES_OT_copy_diagnostic(Operator):
    bl_idname = "diamondeyes.copy_diagnostic"
    bl_label = "Copy Diagnostic Info"
    bl_description = "คัดลอก Version ของ Diamond Eyes, Blender, และ OS ไปยัง Clipboard เผื่อแจ้งปัญหา"

    def execute(self, context):
        version_str = ".".join(str(x) for x in bl_info["version"])
        lines = [
            f"Diamond Eyes: v{version_str}",
            f"Blender: {bpy.app.version_string}",
            f"OS: {platform.system()} {platform.release()}",
        ]
        context.window_manager.clipboard = "\n".join(lines)
        self.report({'INFO'}, f"คัดลอกข้อมูลแล้ว (Diamond Eyes v{version_str})")
        return {'FINISHED'}


class DIAMONDEYES_OT_switch_tab(Operator):
    bl_idname = "diamondeyes.switch_tab"
    bl_label = "สลับแท็บ"
    bl_description = "สลับไปแท็บอื่นใน Diamond Eyes"

    target_tab: StringProperty()

    def execute(self, context):
        context.scene.diamondeyes_active_tab = self.target_tab
        return {'FINISHED'}


class DIAMONDEYES_OT_select_object(Operator):
    bl_idname = "diamondeyes.select_object"
    bl_label = "เลือก Object นี้"
    bl_description = "เลือก Object นี้ใน Viewport ให้เลย (ถ้ายังมีอยู่จริง)"

    name_to_select: StringProperty()

    def execute(self, context):
        obj = bpy.data.objects.get(self.name_to_select)
        if obj is None:
            self.report({'WARNING'}, f"ไม่พบ object ชื่อ '{self.name_to_select}' (อาจถูกลบ/เปลี่ยนชื่อไปแล้ว)")
            return {'CANCELLED'}
        bpy.ops.object.select_all(action='DESELECT')
        obj.select_set(True)
        context.view_layer.objects.active = obj
        self.report({'INFO'}, f"เลือกแล้ว: {obj.name}")
        return {'FINISHED'}


# =====================================================================
# Operator: เลือกทั้งหมด / ไม่เลือกเลย / สลับ
# =====================================================================
class DECALZONE_OT_select_all(Operator):
    bl_idname = "decalzone.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.decalzone_items:
            if item.needs_update:
                item.selected = True
        return {'FINISHED'}


class DECALZONE_OT_select_none(Operator):
    bl_idname = "decalzone.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.decalzone_items:
            item.selected = False
        return {'FINISHED'}


class DECALZONE_OT_select_invert(Operator):
    bl_idname = "decalzone.select_invert"
    bl_label = "สลับการเลือก"

    def execute(self, context):
        for item in context.scene.decalzone_items:
            if item.needs_update:
                item.selected = not item.selected
        return {'FINISHED'}


# =====================================================================
# Operator: Apply - เปลี่ยนชื่อ Object จริงตามที่เลือก
# =====================================================================
class DECALZONE_OT_apply(Operator):
    bl_idname = "decalzone.apply"
    bl_label = "แก้ Condition"
    bl_description = (
        "เปลี่ยนชื่อ Object ตามรายการที่ติ๊กเลือกไว้ (คำนวณจากชื่อ Object จริง ณ ตอนกดเสมอ กดซ้ำกี่ครั้งก็ปลอดภัย) "
        "แล้วเลือก Object ที่เพิ่งแก้ไว้ใน viewport พร้อม log จำนวน/รายชื่อที่แก้"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        link_map = {r.zone: r.companions for r in scene.decalzone_link_rules}

        count = 0
        already_ok = 0
        missing = 0
        changed_objects = []

        for item in scene.decalzone_items:
            if not item.selected:
                continue

            obj = bpy.data.objects.get(item.name)
            if obj is None:
                missing += 1
                continue

            # อ่านค่าจริงจากชื่อ object ปัจจุบันเสมอ ห้ามเชื่อ item.condition ที่อาจค้าง
            # จากการสแกนรอบก่อน -> กดปุ่มนี้ซ้ำกี่ครั้งก็จะไม่มีทางพัง เพราะของที่ถูก
            # อยู่แล้วจะคำนวณได้ผลลัพธ์เดิม แล้วถูกข้ามไปเอง
            current_zone = get_zone(obj.name)
            current_condition = get_condition(obj.name)
            if current_condition is None:
                missing += 1
                continue

            zones_to_add = []
            if current_zone and not zone_in_condition(current_zone, current_condition):
                zones_to_add.append(current_zone)

            # เช็ค companions จาก zone ตัวเอง (ถ้ามี) + ทุก zone ที่มีอยู่ใน Condition อยู่แล้ว
            lookup_zones = set(condition_tokens(current_condition))
            if current_zone:
                lookup_zones.add(current_zone)

            for lz in lookup_zones:
                zones_to_add.extend(parse_companions(link_map.get(lz, "")))

            new_condition = normalize_condition(current_condition, zones_to_add=zones_to_add, sort=scene.decalzone_sort_conditions)

            if new_condition == current_condition:
                # ถูกต้อง/เรียงแล้วอยู่ก่อนแล้ว (เช่น กดซ้ำ) -> ไม่แตะชื่อ object เลย
                already_ok += 1
                item.condition = current_condition
                item.new_condition = current_condition
                item.needs_update = False
                item.selected = False
                item.zone = current_zone or ""
                item.has_zone = bool(current_zone)
                continue

            old_name = obj.name
            obj.name = build_new_name(obj.name, current_condition, new_condition)
            count += 1
            changed_objects.append(obj)
            print(f"[Diamond Eyes] แก้ Condition: {old_name}")
            print(f"    -> {obj.name}")

            # อัปเดตแถวใน List ทันที ไม่ต้องรอ rescan ก็หายจากรายการที่ต้องแก้ได้เลย
            item.name = obj.name
            item.condition = new_condition
            item.new_condition = new_condition
            item.needs_update = False
            item.selected = False
            item.zone = current_zone or ""
            item.has_zone = bool(current_zone)

        msg = f"แก้ไปแล้ว {count} ชิ้น"
        if already_ok:
            msg += f" | ถูกต้องอยู่แล้ว {already_ok} ชิ้น (ข้าม)"
        if missing:
            msg += f" | หา object ไม่เจอ {missing} ชิ้น"
        self.report({'INFO'}, msg)

        if changed_objects:
            print(f"[Diamond Eyes] สรุป: แก้ Condition ไปทั้งหมด {count} ชิ้น:")
            for obj in changed_objects:
                print(f"    - {obj.name}")
            bpy.ops.object.select_all(action='DESELECT')
            for obj in changed_objects:
                obj.select_set(True)
            context.view_layer.objects.active = changed_objects[-1]

        bpy.ops.decalzone.scan()  # สแกนใหม่ให้ตรงกับ scene จริงเสมอ

        for area in context.screen.areas:
            if area.type == 'VIEW_3D':
                area.tag_redraw()

        return {'FINISHED'}


# =====================================================================
# UIList - รายการที่มี ID- (มี zone เป็นของตัวเอง)
# =====================================================================
class DECALZONE_UL_items(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        name_row = col.row(align=True)
        if not item.name_valid:
            name_row.alert = True

        if not item.name_valid:
            name_row.label(text="", icon='ERROR')
        elif item.needs_update:
            name_row.prop(item, "selected", text="")
        else:
            name_row.label(text="", icon='CHECKMARK')

        if item.zone:
            name_row.label(text=item.zone, icon='NONE')
        name_row.label(text=item.name)  # แถวเต็มความกว้าง ชื่อยาวจะไม่ถูกตัดจนอ่านไม่ออก

        detail_row = col.row(align=True)
        detail_row.scale_y = 0.8
        if item.needs_update:
            detail_row.label(text=f"   {item.condition}")
            detail_row.label(text="", icon='TRIA_RIGHT')
            detail_row.label(text=item.new_condition)
        else:
            detail_row.label(text=f"   {item.condition}  (OK)")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        scene = context.scene

        flt_flags = [self.bitflag_filter_item] * len(items)

        zone_filter = scene.decalzone_zone_filter.strip().upper()
        only_needs = scene.decalzone_only_needs_update

        for idx, item in enumerate(items):
            show = True
            if not item.has_zone:
                show = False
            if zone_filter and item.zone != zone_filter:
                show = False
            if only_needs and not item.needs_update and item.name_valid:
                show = False
            if self.filter_name and self.filter_name.lower() not in item.name.lower():
                show = False
            if not show:
                flt_flags[idx] &= ~self.bitflag_filter_item

        flt_neworder = []  # เรียงมาแล้วตอนสแกน ไม่ต้องเรียงซ้ำ
        return flt_flags, flt_neworder


# =====================================================================
# UIList - รายการที่ไม่มี ID- (มีแค่ VIS- เฉย ๆ ไม่มี zone เป็นของตัวเอง)
# =====================================================================
class DECALZONE_UL_items_no_id(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        name_row = col.row(align=True)
        if not item.name_valid:
            name_row.alert = True

        if not item.name_valid:
            name_row.label(text="", icon='ERROR')
        elif item.needs_update:
            name_row.prop(item, "selected", text="")
        else:
            name_row.label(text="", icon='CHECKMARK')

        name_row.label(text=item.name)  # แถวเต็มความกว้าง ชื่อยาวจะไม่ถูกตัดจนอ่านไม่ออก

        detail_row = col.row(align=True)
        detail_row.scale_y = 0.8
        if item.needs_update:
            detail_row.label(text=f"   {item.condition}")
            detail_row.label(text="", icon='TRIA_RIGHT')
            detail_row.label(text=item.new_condition)
        else:
            detail_row.label(text=f"   {item.condition}  (OK)")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        scene = context.scene

        flt_flags = [self.bitflag_filter_item] * len(items)
        only_needs = scene.decalzone_only_needs_update

        for idx, item in enumerate(items):
            show = True
            if item.has_zone:
                show = False
            if only_needs and not item.needs_update and item.name_valid:
                show = False
            if self.filter_name and self.filter_name.lower() not in item.name.lower():
                show = False
            if not show:
                flt_flags[idx] &= ~self.bitflag_filter_item

        flt_neworder = []
        return flt_flags, flt_neworder


# =====================================================================
# UIList - รายการที่ชื่อผิดรูปแบบ (ไม่ตรงตาม Naming Convention)
# =====================================================================
class DECALZONE_UL_items_invalid(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)
        row = col.row(align=True)
        row.alert = True
        row.label(text="", icon='ERROR')
        row.label(text=item.name)
        copy_op = row.operator("diamondeyes.copy_name", text="", icon='COPYDOWN')
        copy_op.name_to_copy = item.name

        detail_row = col.row(align=True)
        detail_row.alert = True
        detail_row.scale_y = 0.8
        detail_row.label(text=f"   {item.name_errors}")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        scene = context.scene

        flt_flags = [self.bitflag_filter_item] * len(items)
        for idx, item in enumerate(items):
            show = not item.name_valid
            if show and self.filter_name and self.filter_name.lower() not in item.name.lower():
                show = False
            if not show:
                flt_flags[idx] &= ~self.bitflag_filter_item

        flt_neworder = []
        return flt_flags, flt_neworder


# =====================================================================
# Panel รวม (แท็บเดียว "Diamond Eyes" มี sub-tab ในตัวสลับ Decal Zone / Material Cleanup)
# =====================================================================
class DIAMONDEYES_PT_panel(Panel):
    bl_label = "Diamond Eyes"
    bl_idname = "DIAMONDEYES_PT_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Diamond Eyes"

    def draw_header(self, context):
        icon_id = diamond_icon_id()
        if icon_id:
            self.layout.label(text="", icon_value=icon_id)

    def draw(self, context):
        layout = self.layout
        scene = context.scene

        # แถวบน: เลือกหมวดหมู่ก่อน
        cat_col = layout.column(align=True)
        cat_col.prop(scene, "diamondeyes_active_category", expand=True)

        # แถวรอง: เลือกเครื่องมือเฉพาะภายในหมวดที่เลือกไว้ (กรองด้วย prop_enum ทีละปุ่ม)
        tool_row = layout.row(align=True)
        for tab_id in TAB_IDS_BY_CATEGORY.get(scene.diamondeyes_active_category, []):
            tool_row.prop_enum(scene, "diamondeyes_active_tab", tab_id)
        layout.separator()

        if scene.diamondeyes_active_tab == 'DECAL_ZONE':
            self.draw_decal_zone(context, layout)
        elif scene.diamondeyes_active_tab == 'MATERIAL_CLEANUP':
            self.draw_material_cleanup(context, layout)
        elif scene.diamondeyes_active_tab == 'DUP_CHECK':
            self.draw_dup_check(context, layout)
        elif scene.diamondeyes_active_tab == 'UV_TOOL':
            self.draw_uv_tool(context, layout)
        elif scene.diamondeyes_active_tab == 'MAT_SPLIT':
            self.draw_split_material(context, layout)
        elif scene.diamondeyes_active_tab == 'SORT_DBR':
            self.draw_sort_debris(context, layout)
        else:
            self.draw_replace_material(context, layout)

        # -------- Version / Diagnostic (แยกจากเครื่องมือหลัก โชว์ทุกแท็บ) --------
        layout.separator()
        version_str = ".".join(str(x) for x in bl_info["version"])
        footer_box = layout.box()
        footer_row = footer_box.row(align=True)
        footer_row.label(text=f"Diamond Eyes v{version_str}", icon='INFO')
        footer_row.operator("diamondeyes.copy_diagnostic", text="", icon='COPYDOWN')

    def draw_decal_zone(self, context, layout):
        scene = context.scene

        # -------- ขั้นตอนการใช้งาน (พับเก็บได้) --------
        help_row = layout.row()
        help_icon = 'TRIA_DOWN' if scene.decalzone_show_help else 'TRIA_RIGHT'
        help_row.prop(scene, "decalzone_show_help", text="ขั้นตอนการใช้งาน", icon=help_icon, emboss=False)
        if scene.decalzone_show_help:
            help_box = layout.box()
            steps = [
                "1) เลือก Collection ที่ต้องการด้านล่าง",
                "2) กด 'สแกน Condition ใน Collection'",
                "3) (ถ้าต้องการ) กรอก Zone Link Rules - preview จะรีเฟรชสดทันทีที่พิมพ์ ไม่ต้องสแกนซ้ำ",
                "4) เช็คกล่อง '⚠ ชื่อผิดรูปแบบ' ด้านล่างสุดก่อน (ถ้ามี) - แก้ชื่อผิดด้วยตนเองก่อนเสมอ",
                "5) เลือกรายการที่ต้องการใน List (มี ID- / ไม่มี ID-) แล้วกด 'แก้ Condition'",
            ]
            for s in steps:
                help_box.label(text=s)
            help_box.label(text="Zone Link Rules ค้างข้ามการสแกน Collection เดิม - ถ้าเพิ่ม object ชุดใหม่ในเดิม", icon='ERROR')
            help_box.label(text="ต้องเช็คทุกแถวเองว่ายังตรงกับที่ตั้งใจไหม (ตัวอักษรซ้ำกันข้ามชุดจะพ่วงข้ามกันได้)")

        layout.separator()

        box = layout.box()
        box.prop(scene, "decalzone_collection", text="Collection")
        box.operator("decalzone.scan", icon='VIEWZOOM')

        # -------- Zone Link Rules --------
        link_box = layout.box()
        link_box.label(text="Zone Link Rules (พ่วงโซนเพิ่มเติม)", icon='LINKED')

        if len(scene.decalzone_link_rules) == 0:
            link_box.label(text="กด 'สแกน Condition ใน Collection' ก่อน เพื่อสร้างช่องกรอกของแต่ละ Zone", icon='INFO')
        else:
            col = link_box.column(align=True)
            for rule in scene.decalzone_link_rules:
                row = col.row(align=True)
                row.label(text=rule.zone)
                row.prop(rule, "companions", text="")
                if rule.companions.strip():
                    row.label(text=f"-> {rule.affected_count} ชิ้น", icon='INFO')

            link_box.label(text="ตัวเลขท้ายแถว = กำลังไปกระทบกี่ object จริง ณ การสแกนล่าสุด เช็คก่อนกด แก้ Condition", icon='INFO')
            link_box.operator("decalzone.clear_link_rules", text="ล้างค่าการพ่วงทั้งหมด", icon='TRASH')

            link_box.label(text="เว้นว่าง = ไม่พ่วง | พิมพ์ Zone คั่นด้วย , เช่น I,J แล้วกด 'สแกน Condition ใน Collection' ใหม่", icon='INFO')
            link_box.label(text="สลับ Collection แล้วสแกน จะล้างค่านี้ให้อัตโนมัติ (กันค่าเก่าหลุดข้าม Collection)", icon='INFO')

        layout.separator()
        layout.prop(scene, "decalzone_zone_filter", text="กรอง Zone (เช่น A)")
        layout.prop(scene, "decalzone_only_needs_update", text="แสดงเฉพาะที่ต้องแก้ไข")
        layout.prop(scene, "decalzone_sort_conditions", text="เรียง Condition ตามตัวอักษร A-Z")

        layout.label(text="มี ID- (มี zone เป็นของตัวเอง)", icon='OUTLINER_OB_MESH')
        layout.template_list(
            "DECALZONE_UL_items", "",
            scene, "decalzone_items",
            scene, "decalzone_items_index",
            rows=10,
        )

        layout.separator()
        layout.label(text="ไม่มี ID- (มีแค่ VIS- เฉย ๆ)", icon='GHOST_ENABLED')
        layout.template_list(
            "DECALZONE_UL_items_no_id", "",
            scene, "decalzone_items",
            scene, "decalzone_items_index_no_id",
            rows=6,
        )

        n_invalid = sum(1 for it in scene.decalzone_items if not it.name_valid)
        if n_invalid:
            layout.separator()
            invalid_box = layout.box()
            invalid_row = invalid_box.row(align=True)
            invalid_row.alert = True
            invalid_row.label(text=f"⚠ ชื่อผิดรูปแบบ ({n_invalid} ชิ้น) - ตรวจสอบด้วยตนเอง", icon='ERROR')
            invalid_box.template_list(
                "DECALZONE_UL_items_invalid", "",
                scene, "decalzone_items",
                scene, "decalzone_items_index_invalid",
                rows=5,
            )
            invalid_box.label(text="แท็บนี้แก้ได้แค่ VIS Condition เอง ไม่แก้โครงสร้างชื่อ (เช่น FDST หาย, LOD ผิด)")
            fix_row = invalid_box.row()
            fix_op = fix_row.operator("diamondeyes.switch_tab", text="ไปแก้โครงสร้างชื่อที่แท็บ Duplicate Name", icon='FILE_REFRESH')
            fix_op.target_tab = 'DUP_CHECK'

        row = layout.row(align=True)
        row.operator("decalzone.select_all", text="เลือกทั้งหมด")
        row.operator("decalzone.select_none", text="ไม่เลือกเลย")
        row.operator("decalzone.select_invert", text="สลับ")

        layout.separator()
        n_needs = sum(1 for it in scene.decalzone_items if it.needs_update)
        n_selected = sum(1 for it in scene.decalzone_items if it.selected and it.needs_update)
        layout.label(text=f"ต้องแก้ {n_needs} ชิ้น | เลือกอยู่ {n_selected} ชิ้น")

        apply_row = layout.row()
        apply_row.scale_y = 1.4
        apply_row.operator("decalzone.apply", icon='FILE_REFRESH')

    def draw_material_cleanup(self, context, layout):
        scene = context.scene

        layout.label(text="ลบ Material Slot ที่ไม่ได้ใช้งานจริงในเนื้อ Mesh", icon='INFO')

        box = layout.box()
        box.prop(scene, "matcleanup_collection", text="Collection")
        box.operator("matcleanup.scan", icon='VIEWZOOM')

        n = len(scene.matcleanup_items)
        if n == 0:
            layout.label(text="ยังไม่พบปัญหา (หรือยังไม่ได้สแกน)", icon='INFO')
            return

        layout.separator()
        header_row = layout.row(align=True)
        header_row.label(text=f"พบ {n} object ที่มี Material ไม่ได้ใช้:", icon='ERROR')
        header_row.operator("matcleanup.copy_all", text="", icon='COPYDOWN')

        n_hidden = sum(1 for it in scene.matcleanup_items if it.is_hidden)
        if n_hidden:
            hidden_box = layout.box()
            hidden_box.alert = True
            hidden_box.label(text=f"⚠ {n_hidden} object ถูกซ่อนอยู่ (ปิดตา) - ต้องเปิดก่อนถึงจะลบ Material ได้", icon='HIDE_ON')
            hidden_box.operator("matcleanup.unhide_hidden", icon='HIDE_OFF')

        layout.template_list(
            "MATCLEANUP_UL_items", "",
            scene, "matcleanup_items",
            scene, "matcleanup_items_index",
            rows=8,
        )

        row = layout.row(align=True)
        row.operator("matcleanup.select_all", text="เลือกทั้งหมด")
        row.operator("matcleanup.select_none", text="ไม่เลือกเลย")
        row.operator("matcleanup.select_invert", text="สลับ")

        n_selected = sum(1 for it in scene.matcleanup_items if it.selected)
        layout.label(text=f"เลือกอยู่ {n_selected} จาก {n} object")

        layout.prop(scene, "matcleanup_sort_after_cleanup", text="เรียง Material ที่เหลือตามชื่อ A-Z ด้วย (ช้าลงถ้ามีหลาย object)")

        warn_box = layout.box()
        warn_box.alert = True
        warn_text = "⚠ ลบ"
        if scene.matcleanup_sort_after_cleanup:
            warn_text += " + เรียงชื่อ A-Z"
        warn_text += " ทันทีที่กด (Ctrl+Z เพื่อ Undo ได้ถ้าพลาด)"
        warn_box.label(text=warn_text, icon='ERROR')

        apply_row = layout.row()
        apply_row.scale_y = 1.4
        apply_row.operator("matcleanup.apply", icon='TRASH')

    def draw_dup_check(self, context, layout):
        scene = context.scene

        help_row = layout.row()
        help_icon = 'TRIA_DOWN' if scene.dupcheck_show_help else 'TRIA_RIGHT'
        help_row.prop(scene, "dupcheck_show_help", text="ขั้นตอนการใช้งาน", icon=help_icon, emboss=False)
        if scene.dupcheck_show_help:
            help_box = layout.box()
            help_box.label(text="หา Object ที่มีปัญหาเกี่ยวกับ FDST / .NNN / LOD 6 แบบ:", icon='INFO')
            help_box.label(text="1) ไม่พบ FDST อยู่ในชื่อ ทั้งที่หน้าตาเป็นชิ้นส่วน decal (มี ID-/VIS-/LOD) - แทรกให้และเลือกไว้ให้เลย")
            help_box.label(text="   (รู้จักคำพิเศษ 'Base' แล้ว - แทรกก่อน Base เสมอ เช่น ..._Base_LOD0 -> ..._FDST_Base_LOD0)")
            help_box.label(text="2) .001, .002... ที่ Blender เติมเองตอนชื่อชนกัน")
            help_box.label(text="3) LOD ที่ถูกอยู่แล้วแต่มีอะไรเกินต่อท้าย เช่น _LOD0.001 หรือ _LOD0_001")
            help_box.label(text="4) MLOD ต้องไม่มีเลขหรืออะไรต่อท้ายเลย (มีแค่ 'MLOD' คำเดียว) - ถ้ามีเกิน แก้ให้อัตโนมัติ")
            help_box.label(text=f"5) LOD ไม่ใช่ตัวเลข เช่น LODasda - ใส่ {LOD_PLACEHOLDER} แทนเลขให้ กำหนดเลขให้ LOD ใหม่เอง")
            help_box.label(text="6) มีทั้ง LOD และ MLOD ในชื่อเดียวกัน (เช่น _LOD3_MLOD312) - เลือกเองว่าจะเอาอันไหน")
            help_box.label(text=f"   (กด Rename ตอนยังมี {LOD_PLACEHOLDER} ค้างอยู่ หรือยังไม่ได้เลือก LOD/MLOD จะถูกข้ามอัตโนมัติ ไม่มีทางเผลอ)")
            help_box.label(text="ช่อง 'ชื่อใหม่' แก้ไขได้เองทุกอัน")
            help_box.label(text="7) ถ้าเจอกลุ่ม duplicate จริง (Zone/Condition เหมือนกันทุกตัว เช่น Wall.001, Wall.002")
            help_box.label(text="   หรือชื่อเหมือนกันทุกอย่าง ต่างกันแค่มี/ไม่มี FDST) จะเสนอ Merge (join เนื้อ Mesh เข้าตัวหลักจริง ๆ)")
            help_box.label(text="   แยกไว้เป็นกล่องต่างหากด้านล่าง ให้ preview ก่อนกดเสมอ")
            help_box.label(text="ยังมี 'Condition Groups Report' แยกต่างหาก - จัดกลุ่ม Object ทั้งหมดตาม LOD/Zone/Condition")
            help_box.label(text="ไม่สนชื่อ mesh ตั้งต้น กรองตาม LOD ได้ และเลือกโชว์เฉพาะกลุ่มที่ซ้ำกันได้")

        layout.separator()

        box = layout.box()
        box.prop(scene, "dupcheck_collection", text="Collection")
        box.operator("dupcheck.scan", icon='VIEWZOOM')

        # -------- Condition Groups report: ภาพรวมว่ามี "เงื่อนไข" อะไรบ้าง ตัวไหนซ้ำกัน --------
        cg_box = layout.box()
        cg_header = cg_box.row()
        cg_icon = 'TRIA_DOWN' if scene.dupcheck_show_condition_groups else 'TRIA_RIGHT'
        cg_header.prop(scene, "dupcheck_show_condition_groups", text="Condition Groups Report", icon=cg_icon, emboss=False)
        if scene.dupcheck_show_condition_groups:
            cg_box.label(text="จัดกลุ่มตาม LOD + Zone + Condition เดียวกัน ไม่สนชื่อ mesh ตั้งต้น", icon='INFO')
            cg_box.operator("dupcheck.scan_condition_groups", icon='VIEWZOOM')

            n_groups = len(scene.dupcheck_condition_groups)
            if n_groups:
                filter_row = cg_box.row(align=True)
                filter_row.prop(scene, "dupcheck_condgroup_lod_filter", text="กรอง LOD (เช่น LOD0)")
                cg_box.prop(scene, "dupcheck_condgroup_only_duplicates", text="แสดงเฉพาะที่ซ้ำกัน (มีปัญหา)")

                n_duplicate_groups = sum(1 for g in scene.dupcheck_condition_groups if g.is_duplicate)
                cg_box.label(
                    text=f"พบ {n_groups} กลุ่ม | ซ้ำกัน {n_duplicate_groups} กลุ่ม",
                    icon='ERROR' if n_duplicate_groups else 'CHECKMARK',
                )
                cg_box.template_list(
                    "DUPCHECK_UL_condition_groups", "",
                    scene, "dupcheck_condition_groups",
                    scene, "dupcheck_condition_groups_index",
                    rows=6,
                )
            else:
                cg_box.label(text="ยังไม่ได้สแกน", icon='INFO')

        n = len(scene.dupcheck_items)
        n_merge = len(scene.dupcheck_merge_groups)

        if n == 0 and n_merge == 0:
            layout.label(text="ยังไม่พบปัญหา (หรือยังไม่ได้สแกน)", icon='INFO')
            return

        # -------- กลุ่ม duplicate จริง ที่เสนอ Merge --------
        if n_merge:
            layout.separator()
            merge_box = layout.box()
            merge_box.label(text=f"พบ duplicate จริง {n_merge} กลุ่ม (Zone/Condition เหมือนกันทุกตัว):", icon='ERROR')
            merge_box.template_list(
                "DUPCHECK_UL_merge_groups", "",
                scene, "dupcheck_merge_groups",
                scene, "dupcheck_merge_groups_index",
                rows=5,
            )
            merge_row = merge_box.row(align=True)
            merge_row.operator("dupcheck.merge_select_all", text="เลือกทั้งหมด")
            merge_row.operator("dupcheck.merge_select_none", text="ไม่เลือกเลย")

            n_merge_selected = sum(1 for g in scene.dupcheck_merge_groups if g.selected)
            merge_box.label(text=f"เลือกอยู่ {n_merge_selected} จาก {n_merge} กลุ่ม")

            merge_warn = merge_box.box()
            merge_warn.alert = True
            merge_warn.label(text="⚠ จะ Merge (join) เนื้อ Mesh เข้าตัวหลักจริง ๆ ไม่ใช่แค่ลบทิ้ง (Ctrl+Z ได้ถ้าพลาด)", icon='ERROR')

            merge_apply_row = merge_box.row()
            merge_apply_row.scale_y = 1.4
            merge_apply_row.operator("dupcheck.merge_apply", icon='TRASH')

        if n == 0:
            return

        layout.separator()
        layout.label(text=f"พบ {n} object ที่มี .001/.002...:", icon='ERROR')
        layout.template_list(
            "DUPCHECK_UL_items", "",
            scene, "dupcheck_items",
            scene, "dupcheck_items_index",
            rows=8,
        )

        n_conflict = sum(1 for it in scene.dupcheck_items if it.has_conflict)
        if n_conflict:
            conflict_box = layout.box()
            conflict_box.alert = True
            conflict_box.label(text=f"⚠ {n_conflict} ตัว ชื่อใหม่จะไปชนกับ object ที่มีอยู่แล้ว - ต้องตั้งชื่อเองแยก", icon='ERROR')

        row = layout.row(align=True)
        row.operator("dupcheck.select_all", text="เลือกทั้งหมด")
        row.operator("dupcheck.select_none", text="ไม่เลือกเลย")
        row.operator("dupcheck.select_invert", text="สลับ")

        n_selected = sum(1 for it in scene.dupcheck_items if it.selected)
        layout.label(text=f"เลือกอยู่ {n_selected} จาก {n} object")

        warn_box = layout.box()
        warn_box.alert = True
        warn_box.label(text="⚠ Rename ทันทีที่กด (Ctrl+Z เพื่อ Undo ได้ถ้าพลาด)", icon='ERROR')

        apply_row = layout.row()
        apply_row.scale_y = 1.4
        apply_row.operator("dupcheck.apply", icon='FILE_REFRESH')

    def draw_uv_tool(self, context, layout):
        scene = context.scene

        layout.label(text="เช็ค UV Map ของ Object เป้าหมาย เทียบว่าแต่ละชิ้นเหมือน/ต่างกันยังไง", icon='INFO')

        # -------- กลุ่มเป้าหมาย --------
        target_box = layout.box()
        target_row = target_box.row(align=True)
        target_row.prop(scene, "uvtool_target_mode", expand=True)
        if scene.uvtool_target_mode == 'COLLECTION':
            target_box.prop(scene, "uvtool_collection", text="Collection")
        else:
            n_selected = len([o for o in context.selected_objects if o.type == 'MESH'])
            target_box.label(text=f"กำลังเลือกอยู่ {n_selected} mesh object ในวิวพอร์ต", icon='RESTRICT_SELECT_OFF')
        target_box.operator("uvtool.scan", icon='VIEWZOOM')

        n = len(scene.uvtool_map_items)
        if n == 0:
            layout.label(text="ยังไม่ได้สแกน", icon='INFO')
            return

        layout.separator()
        n_diff = sum(1 for it in scene.uvtool_map_items if not it.matches_common)
        summary_row = layout.row(align=True)
        summary_row.label(
            text=f"พบ {n} object | ต่างจากส่วนใหญ่ {n_diff} ชิ้น",
            icon='ERROR' if n_diff else 'CHECKMARK',
        )

        layout.template_list(
            "UVTOOL_UL_map_items", "",
            scene, "uvtool_map_items",
            scene, "uvtool_map_items_index",
            rows=8,
        )

        row = layout.row(align=True)
        row.operator("uvtool.select_all", text="เลือกทั้งหมด")
        row.operator("uvtool.select_none", text="ไม่เลือกเลย")
        row.operator("uvtool.select_invert", text="สลับ")
        if n_diff:
            layout.operator("uvtool.select_diff", text="เลือกเฉพาะที่ต่างจากส่วนใหญ่", icon='ERROR')

        n_selected_items = sum(1 for it in scene.uvtool_map_items if it.selected)
        layout.label(text=f"เลือกอยู่ {n_selected_items} จาก {n} object")

        layout.separator()
        action_box = layout.box()
        action_box.prop(scene, "uvtool_target_name", text="ชื่อ UV Map")
        action_row = action_box.row(align=True)
        action_row.operator("uvtool.set_active", text="ตั้งเป็น Active")
        action_row.operator("uvtool.add_uv", text="เพิ่ม", icon='ADD')
        action_row.operator("uvtool.remove_uv", text="ลบ", icon='REMOVE')
        action_box.label(text="ใช้กับ Object ที่ติ๊กเลือกไว้ในลิสต์ด้านบนเท่านั้น", icon='INFO')

    def draw_split_material(self, context, layout):
        scene = context.scene

        layout.label(text="แยก Object ตาม Material เก็บใน Sub-collection ตามชื่อ Material แต่ละอัน", icon='INFO')
        layout.label(text="ลบ Material Slot ที่ไม่ได้ใช้ออกจากชิ้นที่แยกให้ด้วย แล้ว Merge กลับได้ทีหลัง")
        layout.label(text="Object ที่ไม่มี Material หรือมี Material เดียว จะข้ามและแจ้งเตือนให้")

        # -------- กลุ่มเป้าหมาย (ใช้ object ที่เลือกอยู่ในวิวพอร์ตเท่านั้น) --------
        target_box = layout.box()
        n_selected = len([o for o in context.selected_objects if o.type == 'MESH'])
        target_box.label(text=f"กำลังเลือกอยู่ {n_selected} mesh object ในวิวพอร์ต", icon='RESTRICT_SELECT_OFF')

        target_box.operator("splitmat.scan_materials", icon='VIEWZOOM')

        n_mats = len(scene.splitmat_materials)
        if n_mats:
            layout.separator()
            layout.label(text=f"พบ {n_mats} Material - ติ๊กเลือกอันที่จะ Split:", icon='MATERIAL')
            layout.template_list(
                "SPLITMAT_UL_materials", "",
                scene, "splitmat_materials",
                scene, "splitmat_materials_index",
                rows=6,
            )
            mat_sel_row = layout.row(align=True)
            mat_sel_row.operator("splitmat.materials_select_all", text="เลือกทั้งหมด")
            mat_sel_row.operator("splitmat.materials_select_none", text="ไม่เลือกเลย")
            mat_sel_row.operator("splitmat.materials_select_invert", text="สลับ")
            n_mat_selected = sum(1 for m in scene.splitmat_materials if m.selected)
            layout.label(text=f"เลือกอยู่ {n_mat_selected} จาก {n_mats} Material")
        else:
            layout.label(text="กด 'สแกน Material' ก่อน เพื่อดูว่ามี Material อะไรให้เลือก Split บ้าง", icon='INFO')

        dest_box = layout.box()
        dest_box.prop(scene, "splitmat_collection_name", text="ชื่อ Collection ปลายทาง")

        split_row = layout.row()
        split_row.scale_y = 1.4
        split_row.operator("splitmat.split", icon='MOD_EXPLODE')

        layout.separator()
        merge_box = layout.box()
        merge_box.label(text="Merge ชิ้นที่แยกไว้กลับเข้าตัวหลัก", icon='INFO')
        merge_box.label(text=f"อ่านจาก Collection '{scene.splitmat_collection_name.strip() or 'Diamond Eyes - Split'}' ที่ตั้งไว้ด้านบน")
        merge_row = merge_box.row()
        merge_row.scale_y = 1.4
        merge_row.operator("splitmat.merge_back", icon='MOD_BOOLEAN')

    def draw_sort_debris(self, context, layout):
        scene = context.scene

        layout.label(text="จัดเรียงลำดับ Sub-collection ตามชื่อที่ลงท้ายด้วย _dbr_##", icon='INFO')
        layout.label(text="เช็คแค่ชื่อ Collection เท่านั้น ไม่ยุ่งกับ mesh/object ข้างในเลย และไม่เปลี่ยนชื่อใด ๆ")

        box = layout.box()
        box.prop(scene, "sortdbr_collection", text="Collection หลัก")
        dir_row = box.row(align=True)
        dir_row.prop(scene, "sortdbr_direction", expand=True)
        box.operator("sortdbr.scan", icon='VIEWZOOM')

        n = len(scene.sortdbr_items)
        if n == 0:
            layout.label(text="ยังไม่ได้สแกน (หรือไม่พบ Sub-collection ที่มี dbr_## ถูกต้อง)", icon='INFO')
            if scene.sortdbr_invalid_count:
                invalid_row = layout.row()
                invalid_row.alert = True
                invalid_row.label(
                    text=f"⚠ ข้าม {scene.sortdbr_invalid_count} Sub-collection (ชื่อไม่มี dbr_## หรือรูปแบบไม่ถูกต้อง)",
                    icon='ERROR',
                )
            return

        layout.separator()
        dir_label = "น้อยไปมาก" if scene.sortdbr_direction == 'ASC' else "มากไปน้อย"
        layout.label(text=f"พบ {n} Sub-collection ที่มี dbr_## ถูกต้อง (เรียง{dir_label})", icon='CHECKMARK')
        if scene.sortdbr_invalid_count:
            invalid_row = layout.row()
            invalid_row.alert = True
            invalid_row.label(
                text=f"⚠ ข้าม {scene.sortdbr_invalid_count} Sub-collection (ชื่อไม่มี dbr_## หรือรูปแบบไม่ถูกต้อง)",
                icon='ERROR',
            )

        layout.template_list(
            "SORTDBR_UL_items", "",
            scene, "sortdbr_items",
            scene, "sortdbr_items_index",
            rows=8,
        )

        row = layout.row(align=True)
        row.operator("sortdbr.select_all", text="เลือกทั้งหมด")
        row.operator("sortdbr.select_none", text="ไม่เลือกเลย")
        row.operator("sortdbr.select_invert", text="สลับ")

        n_selected = sum(1 for it in scene.sortdbr_items if it.selected)
        layout.label(text=f"เลือกอยู่ {n_selected} จาก {n} Sub-collection")

        warn_box = layout.box()
        warn_box.alert = True
        warn_box.label(text="⚠ จัดเรียงลำดับทันทีที่กด (ไม่เปลี่ยนชื่อเลย - Ctrl+Z ได้ถ้าพลาด)", icon='ERROR')

        apply_row = layout.row()
        apply_row.scale_y = 1.4
        apply_row.operator("sortdbr.apply", icon='SORTSIZE')

    def draw_replace_material(self, context, layout):
        scene = context.scene

        layout.label(text="แทนที่ Material เดิมด้วย Material ใหม่ (ไม่ลบอะไรเลย แค่สลับการอ้างอิง)", icon='INFO')
        layout.label(text="Face ที่ใช้ Material เดิมจะเปลี่ยนไปใช้ Material ปลายทางทันที เนื้อ Mesh ไม่ถูกแตะ")

        target_box = layout.box()
        n_selected = len([o for o in context.selected_objects if o.type == 'MESH'])
        target_box.label(text=f"กำลังเลือกอยู่ {n_selected} mesh object ในวิวพอร์ต", icon='RESTRICT_SELECT_OFF')

        dest_box = layout.box()
        dest_box.prop(scene, "replacemat_target_material", text="Material ปลายทาง (จะใช้แทนที่)")
        dest_box.operator("replacemat.scan", icon='VIEWZOOM')

        n_mats = len(scene.replacemat_materials)
        if n_mats == 0:
            layout.label(text="กด 'สแกน Material' ก่อน เพื่อดูว่ามี Material อะไรให้เลือกแทนที่บ้าง", icon='INFO')
            return

        layout.separator()
        layout.label(text=f"พบ {n_mats} Material - ติ๊กเลือกอันที่จะถูกแทนที่:", icon='MATERIAL')
        layout.template_list(
            "REPLACEMAT_UL_materials", "",
            scene, "replacemat_materials",
            scene, "replacemat_materials_index",
            rows=6,
        )
        sel_row = layout.row(align=True)
        sel_row.operator("replacemat.select_all", text="เลือกทั้งหมด")
        sel_row.operator("replacemat.select_none", text="ไม่เลือกเลย")
        sel_row.operator("replacemat.select_invert", text="สลับ")

        n_mat_selected = sum(1 for m in scene.replacemat_materials if m.selected)
        layout.label(text=f"เลือกอยู่ {n_mat_selected} จาก {n_mats} Material")

        warn_box = layout.box()
        warn_box.alert = True
        warn_box.label(text="⚠ แทนที่ทันทีที่กด (ไม่ลบ Material ใด ๆ - Ctrl+Z ได้ถ้าพลาด)", icon='ERROR')

        apply_row = layout.row()
        apply_row.scale_y = 1.4
        apply_row.operator("replacemat.apply", icon='MATERIAL')


# =====================================================================
# ================  MATERIAL CLEANUP (แท็บแยกต่างหาก)  ================
# =====================================================================
# ลบ Material Slot ที่ไม่มี polygon ไหนในเนื้อ Mesh ใช้เลย
# (เช่น object มี slot A, B แต่ในเนื้อ mesh จริง ๆ ไม่มีหน้าไหนใช้ material B เลย)
# =====================================================================

def find_unused_material_slots(obj):
    """
    คืนค่า list ของ (slot_index, material_name) ที่ไม่มี polygon ไหนในเนื้อ Mesh ใช้เลย
    เช็คเฉพาะ Object ประเภท MESH เท่านั้น
    """
    if obj.type != 'MESH' or obj.data is None:
        return []

    mesh = obj.data
    used_indices = set()
    for poly in mesh.polygons:
        used_indices.add(poly.material_index)

    unused = []
    for i, slot in enumerate(obj.material_slots):
        if i not in used_indices:
            mat_name = slot.material.name if slot.material else "(ว่าง/None)"
            unused.append((i, mat_name))
    return unused


def sort_material_slots_alphabetically(context, obj):
    """
    เรียง Material Slot ของ object ตามชื่อ A-Z (ตัวที่ไม่มี Material ผูกอยู่ไปอยู่ท้ายสุด)
    ใช้คำสั่งย้าย slot มาตรฐานของ Blender (material_slot_move) ทีละขั้น
    เพื่อให้ Blender จัดการ reindex polygon material_index ให้ถูกต้องเอง ไม่เพี้ยนหน้าตา mesh
    """
    if obj.type != 'MESH' or obj.data is None:
        return
    n = len(obj.material_slots)
    if n < 2:
        return

    def key_of(i):
        mat = obj.material_slots[i].material
        return mat.name.upper() if mat else "\uffff"

    context.view_layer.objects.active = obj

    order = [key_of(i) for i in range(n)]
    for i in range(n):
        min_idx = i
        for j in range(i + 1, n):
            if order[j] < order[min_idx]:
                min_idx = j
        while min_idx > i:
            obj.active_material_index = min_idx
            bpy.ops.object.material_slot_move(direction='UP')
            order[min_idx], order[min_idx - 1] = order[min_idx - 1], order[min_idx]
            min_idx -= 1


class MatCleanupItem(PropertyGroup):
    name: StringProperty(name="Object Name")
    unused_count: IntProperty(name="จำนวน Slot ที่ไม่ได้ใช้", default=0)
    unused_materials: StringProperty(name="ชื่อ Material ที่จะลบ", default="")
    is_hidden: BoolProperty(name="ถูกซ่อนอยู่ (ปิดตา)", default=False)
    selected: BoolProperty(name="เลือก", default=True)


# =====================================================================
# Operator: สแกนหา Material ที่ไม่ได้ใช้
# =====================================================================
class MATCLEANUP_OT_scan(Operator):
    bl_idname = "matcleanup.scan"
    bl_label = "สแกน Material ที่ไม่ได้ใช้"
    bl_description = "สแกน Object ทั้งหมดใน Collection (รวม Sub-collection) หา Material Slot ที่ไม่มี polygon ไหนใช้เลย"

    def execute(self, context):
        scene = context.scene
        col = scene.matcleanup_collection

        if col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection ก่อน")
            return {'CANCELLED'}

        scene.matcleanup_items.clear()

        found = []
        n_mesh = 0
        for obj in col.all_objects:
            if obj.type != 'MESH':
                continue
            n_mesh += 1
            unused = find_unused_material_slots(obj)
            if unused:
                found.append((obj.name, unused))

        found.sort(key=lambda x: x[0])

        n_hidden = 0
        for obj_name, unused in found:
            item = scene.matcleanup_items.add()
            item.name = obj_name
            item.unused_count = len(unused)
            item.unused_materials = ", ".join(m for _, m in unused)
            item.selected = True
            obj = bpy.data.objects.get(obj_name)
            is_hidden = obj is not None and not obj.visible_get(view_layer=context.view_layer)
            item.is_hidden = is_hidden
            if is_hidden:
                n_hidden += 1

        n_problem = len(found)
        n_slots = sum(len(u) for _, u in found)
        note = f" | ⚠ ถูกซ่อนอยู่ {n_hidden} ชิ้น (ต้องเปิดตาก่อนถึงจะลบได้)" if n_hidden else ""
        self.report(
            {'INFO'} if n_problem == 0 else {'WARNING'},
            f"สแกน Mesh {n_mesh} ชิ้น | พบ {n_problem} ชิ้นที่มี Material ไม่ได้ใช้ รวม {n_slots} slot{note}",
        )
        return {'FINISHED'}


# =====================================================================
# Operator: เปิดตา Object ที่ถูกซ่อนอยู่ในรายการทั้งหมด
# =====================================================================
class MATCLEANUP_OT_unhide_hidden(Operator):
    bl_idname = "matcleanup.unhide_hidden"
    bl_label = "เปิดตา Object ที่ถูกซ่อนทั้งหมด"
    bl_description = "เปิดตา (Outliner) และเปิด Viewport ให้ Object ที่ถูกซ่อนอยู่ในรายการนี้ทั้งหมด แล้วสแกนใหม่ให้อัตโนมัติ"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        count = 0
        for item in scene.matcleanup_items:
            if not item.is_hidden:
                continue
            obj = bpy.data.objects.get(item.name)
            if obj is None:
                continue
            obj.hide_set(False)
            obj.hide_viewport = False
            count += 1

        self.report({'INFO'}, f"เปิดตาให้ {count} object แล้ว")
        bpy.ops.matcleanup.scan()  # สแกนใหม่ให้สถานะ is_hidden อัปเดตตรงกับความจริง
        return {'FINISHED'}


# =====================================================================
# Operator: เลือกทั้งหมด / ไม่เลือกเลย / สลับ
# =====================================================================
class MATCLEANUP_OT_select_all(Operator):
    bl_idname = "matcleanup.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.matcleanup_items:
            item.selected = True
        return {'FINISHED'}


class MATCLEANUP_OT_select_none(Operator):
    bl_idname = "matcleanup.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.matcleanup_items:
            item.selected = False
        return {'FINISHED'}


class MATCLEANUP_OT_select_invert(Operator):
    bl_idname = "matcleanup.select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.matcleanup_items:
            item.selected = not item.selected
        return {'FINISHED'}


# =====================================================================
# Operator: ลบ Material ที่ไม่ได้ใช้จริง (เฉพาะตัวที่ติ๊กเลือกไว้)
# =====================================================================
class MATCLEANUP_OT_apply(Operator):
    bl_idname = "matcleanup.apply"
    bl_label = "ลบ Material ที่ไม่ได้ใช้"
    bl_description = (
        "ลบ Material Slot ที่ไม่ได้ใช้งานจริง (Object ที่ติ๊กเลือกไว้ - Ctrl+Z ได้ถ้าพลาด) "
        "แล้วเลือก Object ที่เพิ่งแก้ไว้ใน viewport พร้อม log จำนวน/รายชื่อที่แก้"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene

        targets = []
        hidden_skipped = []
        for item in scene.matcleanup_items:
            if not item.selected:
                continue
            obj = bpy.data.objects.get(item.name)
            if obj is None:
                continue
            # เช็คซ้ำจากข้อมูลจริง ณ ตอนกด กันเคส mesh ถูกแก้ไปแล้วระหว่างที่ list ยังค้างอยู่
            if not find_unused_material_slots(obj):
                continue
            # object ที่ถูกซ่อนอยู่ (hide_get / ปิด eye ใน Outliner / อยู่ใน Collection ที่ปิด)
            # เรียก material_slot_remove_unused ไม่ได้ ต้อง unhide ก่อนเอง -> ข้ามแล้วแจ้งเตือนแทน
            if not obj.visible_get(view_layer=context.view_layer):
                hidden_skipped.append(obj.name)
                continue
            targets.append(obj)

        if not targets:
            msg = "ไม่มี Object ที่ต้องลบ Material (อาจถูกแก้ไปแล้ว หรือยังไม่ได้ติ๊กเลือก)"
            if hidden_skipped:
                msg += f" | ข้าม {len(hidden_skipped)} ชิ้นเพราะถูกซ่อนอยู่ (เปิดให้เห็นก่อนแล้วลองใหม่)"
            self.report({'WARNING'}, msg)
            return {'CANCELLED'}

        # เลือก target ไว้ก่อนเพื่อรันคำสั่งลบ slot มาตรฐานของ Blender (ต้องใช้ selection)
        bpy.ops.object.select_all(action='DESELECT')
        for obj in targets:
            obj.select_set(True)
        context.view_layer.objects.active = targets[0]

        try:
            bpy.ops.object.material_slot_remove_unused()
        except RuntimeError as e:
            self.report({'ERROR'}, f"ลบ Material Slot ไม่สำเร็จ: {e}")
            return {'CANCELLED'}

        # เรียง Material Slot ตามชื่อ A-Z เป็น option แยก (ปิดไว้เป็นค่าเริ่มต้น เพราะทำให้ช้าถ้ามีหลาย object)
        sorted_note = ""
        if scene.matcleanup_sort_after_cleanup:
            for obj in targets:
                sort_material_slots_alphabetically(context, obj)
            sorted_note = " + เรียงชื่อ A-Z"

        # คงเลือก object ที่เพิ่งแก้ไว้ให้เห็นชัด ๆ (ไม่คืน selection เดิมแล้ว)
        bpy.ops.object.select_all(action='DESELECT')
        for obj in targets:
            obj.select_set(True)
        context.view_layer.objects.active = targets[-1]

        print(f"[Diamond Eyes] ลบ Material Slot ที่ไม่ได้ใช้{sorted_note} ไปทั้งหมด {len(targets)} object:")
        for obj in targets:
            print(f"    - {obj.name}")
        if hidden_skipped:
            print(f"[Diamond Eyes] ข้าม {len(hidden_skipped)} object เพราะถูกซ่อนอยู่:")
            for name in hidden_skipped:
                print(f"    - {name}")

        msg = f"ลบ Material Slot ที่ไม่ได้ใช้{sorted_note}ให้ {len(targets)} object แล้ว"
        if hidden_skipped:
            msg += f" | ข้าม {len(hidden_skipped)} ชิ้นเพราะถูกซ่อนอยู่"
        self.report({'INFO'}, msg)

        bpy.ops.matcleanup.scan()  # สแกนใหม่ให้ตรงกับสถานะล่าสุด
        return {'FINISHED'}


class MATCLEANUP_OT_copy_all(Operator):
    bl_idname = "matcleanup.copy_all"
    bl_label = "Copy รายชื่อทั้งหมด"
    bl_description = "คัดลอกรายชื่อ Object และ Material ที่จะลบทั้งหมดไปยัง Clipboard (บรรทัดละ 1 object)"

    def execute(self, context):
        lines = [f"{it.name}: {it.unused_materials}" for it in context.scene.matcleanup_items]
        context.window_manager.clipboard = "\n".join(lines)
        self.report({'INFO'}, f"คัดลอกแล้ว {len(lines)} object")
        return {'FINISHED'}


# =====================================================================
# UIList
# =====================================================================
class MATCLEANUP_UL_items(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        name_row = col.row(align=True)
        if item.is_hidden:
            name_row.alert = True
            name_row.label(text="", icon='HIDE_ON')
        name_row.prop(item, "selected", text="")
        name_row.label(text=item.name)
        copy_op = name_row.operator("diamondeyes.copy_name", text="", icon='COPYDOWN')
        copy_op.name_to_copy = item.name

        count_row = col.row(align=True)
        count_row.scale_y = 0.8
        if item.is_hidden:
            count_row.alert = True
            count_row.label(text=f"   ⚠ ถูกซ่อนอยู่ - ต้องเปิดตาก่อน | {item.unused_count} slot ที่ไม่ได้ใช้:")
        else:
            count_row.label(text=f"   {item.unused_count} slot ที่ไม่ได้ใช้:")

        # แยก Material แต่ละชื่อลงมาทีละบรรทัด กันชื่อยาวๆ วิ่งเลยขอบจนอ่านไม่เห็น
        mat_names = [m.strip() for m in item.unused_materials.split(",") if m.strip()]
        for mat_name in mat_names:
            mat_row = col.row(align=True)
            mat_row.scale_y = 0.8
            mat_row.label(text=f"      • {mat_name}")


# =====================================================================
# ==========  DUPLICATE OBJECT NAME CHECKER (แท็บย่อยที่ 3)  ==========
# =====================================================================
# หา Object ที่มีปัญหาเกี่ยวกับ .NNN / LOD 3 แบบ:
#   1) ลงท้ายด้วย .001 .002 ... ธรรมดา (Blender auto-rename ตอนชื่อชนกัน)
#   2) มี LOD/MLOD ที่ถูกต้องอยู่แล้ว แต่ดันมีอะไรเกินต่อท้ายอีก ไม่ว่าจะเป็น
#      รูปแบบจุด (..._LOD0.001) หรือขีดล่าง (..._LOD0_001) ก็ตาม
#      -> กรณีนี้ต้องเหลือแค่ LODN เท่านั้น ไม่ใช่แปลงเป็น _001
#   3) มี token หน้าตาเหมือนตั้งใจจะเป็น LOD/MLOD แต่ไม่มีเลขต่อท้ายถูกต้องเลย
#      (เช่น LODasda) -> ทายเลขที่ถูกต้องไม่ได้ เสนอ LOD0 เป็นค่าเริ่มต้น
#      ให้ user แก้เป็นเลขที่ถูกต้องเองในช่องก่อนกด Rename
# แสดงรายการ + เสนอชื่อใหม่ (แก้ไขได้) ก่อน Rename จริงจะเตือน/ให้ preview เสมอ
# =====================================================================

DOT_SUFFIX_PATTERN = re.compile(r'^(.*)\.(\d{3})$')
LOD_EXCESS_PATTERN = re.compile(r'^(.*_(?:LOD\d+|MLOD))([._].+)$', re.IGNORECASE)
LOD_INVALID_TOKEN_PATTERN = re.compile(r'^(M?)LOD(.+)$', re.IGNORECASE)
LOD_PLACEHOLDER = "$$$"  # ใช้แทนเลข LOD ที่ทายไม่ได้ ให้เห็นชัดว่าต้องกรอกเอง (ไม่เดาเป็น 0 เงียบ ๆ)

# token แบบตัวอักษร+เลข ใน ID-A1 (zone identifier ตามธรรมเนียมที่ใช้จริงในระบบนี้) -> ใช้จัดลำดับ
# ให้ตัวที่มี zone identifier แบบนี้ขึ้นก่อนเสมอใน list ของแท็บ Duplicate Name
# (เช็คเฉพาะในตำแหน่ง ID- เท่านั้น ไม่เช็ค token เดี่ยว ๆ เพราะจะไปชนกับของอื่นที่ไม่เกี่ยวกัน
# เช่น 'V2' ที่เป็นเลขเวอร์ชันใน mesh name ก็เข้ารูปแบบตัวอักษร+เลขเหมือนกันแต่ไม่ใช่ zone)
ID_LETTER_DIGIT_PATTERN = re.compile(r'^ID[-_]([A-Za-z]\d+)$', re.IGNORECASE)


def has_letter_digit_zone(name):
    """เช็คว่าชื่อมี zone identifier แบบ ID-ตัวอักษร+เลข (เช่น ID-A1, ID-B12) อยู่ไหม"""
    for t in name.split('_'):
        if ID_LETTER_DIGIT_PATTERN.match(t):
            return True
    return False


def compare_uv_maps_in_group(keep_name, remove_names):
    """
    เทียบชื่อ UV Map (เป็นเซ็ต) ระหว่าง object ที่จะเก็บไว้กับตัวที่จะลบทั้งหมดในกลุ่มเดียวกัน
    คืนค่า (match: bool, note: str) - note อธิบายว่าตัวไหนมี UV ต่างจาก keep_name บ้าง
    """
    keep_obj = bpy.data.objects.get(keep_name)
    if keep_obj is None or keep_obj.type != 'MESH' or keep_obj.data is None:
        return True, ""
    keep_uv_set = frozenset(l.name for l in keep_obj.data.uv_layers)

    diffs = []
    for rn in remove_names:
        robj = bpy.data.objects.get(rn)
        if robj is None or robj.type != 'MESH' or robj.data is None:
            continue
        this_set = frozenset(l.name for l in robj.data.uv_layers)
        if this_set != keep_uv_set:
            diffs.append(rn)

    if diffs:
        return False, f"UV ไม่ตรงกับ '{keep_name}': {', '.join(diffs)}"
    return True, ""


def set_active_uv_to_first(obj):
    """ตั้ง UV Map ตัวแรกสุดในลิสต์ (index 0) ให้เป็น Active (และ Active Render)"""
    if obj is None or obj.type != 'MESH' or obj.data is None:
        return
    uv_layers = obj.data.uv_layers
    if len(uv_layers) == 0:
        return
    first_layer = uv_layers[0]
    uv_layers.active = first_layer
    first_layer.active_render = True


# =====================================================================
# Condition Groups report - จัดกลุ่ม object ทั้งฉากตาม (LOD, Zone, Condition)
# ไม่สนใจว่าชื่อ mesh ตั้งต้นจะเหมือนกันหรือไม่ ใช้เพื่อรายงานภาพรวมว่ามี "เงื่อนไข" อะไรบ้าง
# ตัวไหนซ้ำกัน (เช่น สอง mesh คนละชื่อ แต่ LOD/Zone/Condition ตรงกันเป๊ะ = อาจเป็นปัญหา)
# แยกจาก find_mergeable_duplicate_groups ด้านล่าง (อันนั้นจับคู่จากชื่อที่ตรงกันเป๊ะ + .NNN)
# =====================================================================

NO_LOD_LABEL = "(ไม่มี LOD)"
NO_ZONE_LABEL = "(ไม่มี ID)"


def get_lod_token(name):
    """หา token ที่เป็น LOD/MLOD ที่ถูกต้อง (เช่น 'LOD0', 'MLOD') จากชื่อ object คืนค่า None ถ้าไม่เจอ"""
    for token in name.split('_'):
        if LOD_TOKEN_PATTERN.match(token):
            return token.upper()
    return None


class ConditionGroup:
    """
    หนึ่งกลุ่มของ object ที่มี (LOD, Zone, Condition) ตรงกันเป๊ะ
    ใช้เป็นข้อมูลกลาง ก่อนแปลงเป็น ConditionGroupItem สำหรับแสดงผลใน UIList
    """
    def __init__(self, lod, zone, condition):
        self.lod = lod
        self.zone = zone
        self.condition = condition
        self.object_names = []

    @property
    def count(self):
        return len(self.object_names)

    @property
    def is_duplicate(self):
        """มากกว่า 1 ชิ้นในกลุ่มเดียวกัน = อาจเป็นปัญหา (สอง mesh คนละชื่อแต่เงื่อนไขตรงกันเป๊ะ)"""
        return self.count > 1

    def sort_key(self):
        """เรียงตาม alphabet โดยเอา Condition ขึ้นก่อนเป็นหลัก ตามด้วย Zone แล้วค่อย LOD"""
        return (self.condition, self.zone, self.lod)


def build_condition_groups(collection):
    """
    ไล่ดู object ทุกตัวใน collection ที่มี VIS- Condition แล้วจัดกลุ่มตาม (LOD, Zone, Condition)
    คืนค่า list ของ ConditionGroup เรียงตาม Condition ก่อนเป็นหลักแล้ว (ดู sort_key)
    """
    groups_by_key = {}

    for obj in collection.all_objects:
        condition = get_condition(obj.name)
        if condition is None:
            continue  # ไม่มี VIS- เลย ไม่เกี่ยวกับรายงานนี้

        lod = get_lod_token(obj.name) or NO_LOD_LABEL
        zone = get_zone(obj.name) or NO_ZONE_LABEL

        key = (lod, zone, condition)
        if key not in groups_by_key:
            groups_by_key[key] = ConditionGroup(lod, zone, condition)
        groups_by_key[key].object_names.append(obj.name)

    groups = list(groups_by_key.values())
    for g in groups:
        g.object_names.sort()
    groups.sort(key=ConditionGroup.sort_key)
    return groups


def find_mergeable_duplicate_groups(collection):
    """
    หา object ที่เป็น duplicate จริง ๆ: base name (ก่อน .NNN) ตรงกันเป๊ะ + Zone (ID-) และ
    Condition (VIS-) เหมือนกันทุกตัวในกลุ่ม เช่น Wall_A1, Wall_A1.001, Wall_A1.002
    คืนค่า list ของ dict {'keep': ชื่อที่จะเก็บไว้, 'remove': [ชื่อที่จะลบ, ...]}
    ตัวที่ไม่มี .NNN (base เปล่า ๆ) จะถูกเลือกเก็บไว้ก่อนเสมอ ถ้าไม่มีเลยจะเก็บเลข .NNN ต่ำสุด
    """
    groups = {}
    for obj in collection.all_objects:
        name = obj.name
        m = DOT_SUFFIX_PATTERN.match(name)
        if m:
            base, suffix_num = m.group(1), int(m.group(2))
        else:
            base, suffix_num = name, -1
        groups.setdefault(base, []).append((suffix_num, name))

    mergeable = []
    for base, members in groups.items():
        if len(members) < 2:
            continue
        # เช็คว่า Zone + Condition เหมือนกันทุกตัวในกลุ่มไหม (กันเหนียว - base ตรงกันเป๊ะอยู่แล้วโดยปกติ
        # ก็ควรจะได้ zone/condition เดียวกันอยู่แล้ว แต่เช็คซ้ำไว้เพื่อความชัวร์)
        zc_set = set((get_zone(n), get_condition(n)) for _, n in members)
        if len(zc_set) != 1:
            continue
        members_sorted = sorted(members, key=lambda m: m[0])  # ไม่มี suffix (-1) มาก่อนเสมอ แล้วค่อย 001, 002...
        keep = members_sorted[0][1]
        remove = [m[1] for m in members_sorted[1:]]
        mergeable.append({'keep': keep, 'remove': remove})

    # เรียง: กลุ่มที่ตัวเก็บไว้มี zone แบบ ตัวอักษร+เลข (เช่น A1) ขึ้นก่อนเสมอ แล้วค่อยตามชื่อ
    mergeable.sort(key=lambda g: (not has_letter_digit_zone(g['keep']), g['keep']))

    return mergeable


# คำพิเศษอื่น ๆ ที่ถือเป็น "จุดเริ่มต้นของส่วนต่อท้ายชื่อ" เหมือน ID-/VIS-/LOD (ต้องมี FDST อยู่หน้าเสมอ)
# เช่น ..._Base_LOD0 -> FDST ต้องแทรกก่อน 'Base' ไม่ใช่ก่อน LOD0 (ให้ผลเป็น ..._FDST_Base_LOD0)
# เพิ่มคำอื่นในเซ็ตนี้ได้ตามต้องการ (เช่น 'ROOT', 'MAIN') ถ้ามีธรรมเนียมการตั้งชื่อแบบเดียวกัน
SPECIAL_MARKER_WORDS = {"BASE"}


def looks_like_decal_piece(name):
    """
    เช็คว่าชื่อนี้ 'น่าจะ' เป็นชิ้นส่วนในระบบ Decal/Destructible ไหม (มี VIS-, FDST, ID-, LOD/MLOD, หรือคำพิเศษ)
    ใช้ตัดสินว่าควรเช็คหา FDST ที่หายไปไหม กัน object อื่นที่ไม่เกี่ยวข้องเลย (เช่น กล้อง, ไฟ) โดนเช็คผิดที่
    """
    up = name.upper()
    if 'VIS-' in up or FDST_TAG in up:
        return True
    for t in name.split('_'):
        tu = t.upper()
        if tu.startswith('ID-') or tu.startswith('ID_'):
            return True
        if LOD_LIKE_PATTERN.match(t):
            return True
        if tu in SPECIAL_MARKER_WORDS:
            return True
    return False


FDST_GLUED_BEFORE_PATTERN = re.compile(r'([A-Za-z0-9])(FDST)', re.IGNORECASE)
FDST_GLUED_AFTER_PATTERN = re.compile(r'(FDST)([A-Za-z0-9])', re.IGNORECASE)
GLUED_PREFIX_ID_VIS_PATTERN = re.compile(r'^([A-Za-z0-9]*)(ID-|ID_|VIS-)(.*)$', re.IGNORECASE)


def fix_fdst_glue(name):
    """
    เช็คว่าคำว่า FDST ในชื่อนี้ติดกับตัวอักษรข้างเคียงโดยไม่มี _ คั่นไหม (ก่อนหน้า และ/หรือ ตามหลัง)
    เช่น 'smokestackFDST_ID-A' (ขาด _ ก่อน FDST) หรือ 'FDSTID-A' (ขาด _ หลัง FDST) หรือทั้งคู่พร้อมกัน
    คืนค่า (fixed_name, was_fixed: bool) - was_fixed=False แปลว่าไม่มีปัญหานี้ (หรือไม่มี FDST เลย)
    """
    if FDST_TAG not in name.upper():
        return name, False
    fixed = FDST_GLUED_BEFORE_PATTERN.sub(lambda m: f"{m.group(1)}_{m.group(2)}", name)
    fixed = FDST_GLUED_AFTER_PATTERN.sub(lambda m: f"{m.group(1)}_{m.group(2)}", fixed)
    return fixed, (fixed != name)


def propose_fdst_insertion(name):
    """
    คำนวณชื่อที่ควรเป็นถ้าแทรก FDST เข้าไป (ก่อน ID-/VIS-/LOD/คำพิเศษ ตัวแรกที่เจอ)
    ถ้า token ที่เจอดันมีตัวอักษรเกินติดหน้า ID-/VIS- อยู่ (เช่น 'FID-A' ที่ 'F' น่าจะเป็นเศษ FDST
    ที่พิมพ์ตกหล่นไป) จะตัดตัวอักษรเกินนั้นทิ้งแล้วแทรก FDST เข้าไปแทนที่ให้เลย
    """
    tokens = name.split('_')
    insert_at = len(tokens)
    for i, t in enumerate(tokens):
        tu = t.upper()
        if tu.startswith('ID-') or tu.startswith('ID_') or tu.startswith('VIS-'):
            insert_at = i
            break
        if LOD_LIKE_PATTERN.match(t) or tu in SPECIAL_MARKER_WORDS:
            insert_at = i
            break
        m = GLUED_PREFIX_ID_VIS_PATTERN.match(t)
        if m and m.group(1):
            # token นี้มีตัวอักษรเกินติดอยู่หน้า ID-/VIS- (เช่น 'FID-A') -> ตัดทิ้งแล้วแทรก FDST แทนตรงนี้เลย
            clean_token = m.group(2) + m.group(3)
            new_tokens = tokens[:i] + [FDST_TAG, clean_token] + tokens[i + 1:]
            return '_'.join(new_tokens)
    return '_'.join(tokens[:insert_at] + [FDST_TAG] + tokens[insert_at:])


def find_fdst_duplicate_groups(collection):
    """
    หา object 2 ตัวที่ชื่อเหมือนกันทุกอย่าง (LOD, VIS, ID, ส่วนอื่น ๆ) ต่างกันแค่มี/ไม่มี _FDST_
    เช่น 'X_VIS-A_LOD0' กับ 'X_FDST_VIS-A_LOD0' มีอยู่คู่กันในฉากจริง -> ถือเป็น duplicate จริง
    เสนอ merge (เก็บตัวที่มี FDST อยู่แล้วไว้ ลบตัวที่ไม่มีทิ้ง) แทนที่จะ rename แล้วชนชื่อ
    """
    all_names = set(o.name for o in collection.all_objects)
    mergeable = []
    for obj in collection.all_objects:
        name = obj.name
        tokens = name.split('_')
        if any(t.upper() == FDST_TAG for t in tokens):
            continue  # ตัวนี้มี FDST อยู่แล้ว ไม่ใช่ตัวที่ต้องหาคู่
        if not looks_like_decal_piece(name):
            continue

        with_fdst_name = propose_fdst_insertion(name)
        if with_fdst_name == name or with_fdst_name not in all_names:
            continue

        # เช็คซ้ำว่า Zone (ID-) และ Condition (VIS-) เหมือนกันจริง กันเหนียว (ปกติต้องเหมือนกันอยู่แล้ว
        # เพราะชื่อเหมือนกันทุกตัวอักษรยกเว้น FDST)
        if (get_zone(name), get_condition(name)) != (get_zone(with_fdst_name), get_condition(with_fdst_name)):
            continue

        mergeable.append({'keep': with_fdst_name, 'remove': [name]})

    return mergeable


def find_duplicate_suffix_objects(collection, skip_names=None):
    """
    คืนค่า list ของ (obj_name, proposed_new_name, reason) สำหรับ object ที่มีปัญหา
    เกี่ยวกับ .NNN หรือ LOD (ดูรายละเอียด 4 แบบ) เช็คตามลำดับความสำคัญ:
    ไม่มี FDST เลย -> LOD+MLOD ชนกัน (ต้องแก้เองก่อนเสมอ) -> LOD-excess -> DOT-suffix -> LOD-invalid/MLOD-invalid
    skip_names: ชื่อ object ที่ถูกจัดการผ่านทาง Merge ไปแล้ว ไม่ต้องเอามาแสดงซ้ำในลิสต์นี้
    """
    skip_names = skip_names or set()
    found = []
    for obj in collection.all_objects:
        name = obj.name
        if name in skip_names:
            continue
        tokens = name.split('_')

        # เช็คก่อน: มี FDST อยู่แล้ว แต่ติดกับตัวอักษรข้างเคียงไม่มี _ คั่น (เช่น 'smokestackFDST' หรือ 'FDSTID-A')
        glued_fixed_name, was_glued = fix_fdst_glue(name)
        if was_glued:
            found.append((name, glued_fixed_name, "FDST_GLUED"))
            continue

        # หน้าตาเหมือนเป็นชิ้นส่วน decal (มี VIS-/ID-/LOD/Base อยู่แล้ว) แต่ดันไม่มี FDST เลย
        # (ถ้ามีคู่ที่มี FDST อยู่แล้วในฉากพอดี จะถูกจัดการผ่าน merge_groups ไปแล้ว ไม่มาถึงตรงนี้อีก
        # เพราะ skip_names ครอบคลุมไว้แล้วตอนเรียกฟังก์ชันนี้)
        if not any(t.upper() == FDST_TAG for t in tokens) and looks_like_decal_piece(name):
            new_name = propose_fdst_insertion(name)
            found.append((name, new_name, "MISSING_FDST"))
            continue

        # มี token หน้าตาเหมือน LOD/MLOD มากกว่า 1 ตัวในชื่อเดียวกัน (เช่น มีทั้ง LOD3 และ MLOD312)
        # -> ไม่รู้ว่าควรเป็น LOD หรือ MLOD กันแน่ ต้องให้ user ตัดสินใจเอง ไม่แตะ/เดาให้เด็ดขาด
        lod_like_indices = [i for i, t in enumerate(tokens) if LOD_LIKE_PATTERN.match(t)]
        if len(lod_like_indices) > 1:
            found.append((name, name, "LOD_MLOD_CONFLICT"))
            continue

        m_lod = LOD_EXCESS_PATTERN.match(name)
        if m_lod:
            clean_prefix = m_lod.group(1)
            found.append((name, clean_prefix, "LOD_EXCESS"))
            continue

        m_dot = DOT_SUFFIX_PATTERN.match(name)
        if m_dot:
            base, num = m_dot.group(1), m_dot.group(2)
            found.append((name, f"{base}_{num}", "DOT"))
            continue

        # เช็ค token ที่หน้าตาเหมือน LOD/MLOD แต่ผิดรูปแบบ
        # - LODxxx (ไม่ใช่ LOD+เลข) -> ทายเลขที่ถูกไม่ได้ ใส่ $$$ ให้กรอกเอง
        # - MLODxxx (MLOD ต้องไม่มีอะไรต่อท้ายเลย) -> รู้คำตอบที่ถูกต้องแน่นอนอยู่แล้วคือ 'MLOD' เฉย ๆ แก้ให้ได้เลย
        for i, t in enumerate(tokens):
            if LOD_TOKEN_PATTERN.match(t):
                continue  # ถูกอยู่แล้ว ข้าม
            m_inv = LOD_INVALID_TOKEN_PATTERN.match(t)
            if m_inv:
                is_mlod = bool(m_inv.group(1))  # ขึ้นต้นด้วย M หรือไม่
                new_tokens = list(tokens)
                if is_mlod:
                    new_tokens[i] = "MLOD"
                    found.append((name, '_'.join(new_tokens), "MLOD_FIX"))
                else:
                    new_tokens[i] = f"LOD{LOD_PLACEHOLDER}"
                    found.append((name, '_'.join(new_tokens), "LOD_INVALID"))
                break

    return found


def _on_dupcheck_new_name_update(self, context):
    # แก้ชื่อใหม่ในช่องแล้ว เช็คชนซ้ำ + เช็คว่ายังมี $$$ ค้างอยู่ไหม + ยังมี LOD/MLOD ชนกันไหม สดทันที
    scene = context.scene
    existing_names = set(o.name for o in bpy.data.objects)
    target_counts = {}
    for it in scene.dupcheck_items:
        target_counts[it.new_name] = target_counts.get(it.new_name, 0) + 1
    for it in scene.dupcheck_items:
        it.has_conflict = (
            (it.new_name in existing_names and it.new_name != it.name)
            or target_counts[it.new_name] > 1
        )
        it.needs_number = (LOD_PLACEHOLDER in it.new_name)
        lod_like_count = len([t for t in it.new_name.split('_') if LOD_LIKE_PATTERN.match(t)])
        it.needs_choice = (lod_like_count > 1)


class DupCheckItem(PropertyGroup):
    name: StringProperty(name="Object Name")
    new_name: StringProperty(name="ชื่อใหม่ที่เสนอ", update=_on_dupcheck_new_name_update)
    reason: StringProperty(name="สาเหตุ", default="")
    has_conflict: BoolProperty(name="ชื่อใหม่ชนกับที่มีอยู่แล้ว", default=False)
    needs_number: BoolProperty(name="ยังไม่ได้กรอกเลข LOD", default=False)
    needs_choice: BoolProperty(name="มี LOD/MLOD ชนกัน ต้องเลือกเอง", default=False)
    selected: BoolProperty(name="เลือก", default=True)


class MergeGroupItem(PropertyGroup):
    keep_name: StringProperty(name="เก็บไว้")
    remove_names: StringProperty(name="จะลบทิ้ง", default="")  # คั่นด้วย ", " สำหรับแสดงผล
    remove_count: IntProperty(default=0)
    uv_match: BoolProperty(name="UV ตรงกันทุกตัว", default=True)
    uv_note: StringProperty(name="รายละเอียด UV ที่ต่างกัน", default="")
    selected: BoolProperty(name="เลือก", default=True)


# =====================================================================
# Condition Groups report - PropertyGroup + Operator + UIList
# แสดงภาพรวมว่าในฉากมี "เงื่อนไข" (LOD + Zone + Condition) อะไรบ้าง ตัวไหนซ้ำกัน
# (ดู build_condition_groups ด้านบนสำหรับ logic การจัดกลุ่ม)
# =====================================================================

class ConditionGroupItem(PropertyGroup):
    lod: StringProperty(default="")
    zone: StringProperty(default="")
    condition: StringProperty(default="")
    object_names: StringProperty(default="")  # คั่นด้วย ", " สำหรับแสดงผล
    count: IntProperty(default=0)
    is_duplicate: BoolProperty(default=False)


class DUPCHECK_OT_scan_condition_groups(Operator):
    bl_idname = "dupcheck.scan_condition_groups"
    bl_label = "สแกน Condition Groups"
    bl_description = (
        "จัดกลุ่ม Object ทั้งหมดใน Collection ตาม LOD + Zone (ID-) + Condition (VIS-) ที่ตรงกันเป๊ะ "
        "ไม่สนใจว่าชื่อ mesh ตั้งต้นจะเหมือนกันหรือไม่ - กลุ่มที่มีมากกว่า 1 ชิ้นถือเป็นปัญหา"
    )

    def execute(self, context):
        scene = context.scene
        col = scene.dupcheck_collection
        if col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection ก่อน")
            return {'CANCELLED'}

        scene.dupcheck_condition_groups.clear()

        groups = build_condition_groups(col)
        for g in groups:
            item = scene.dupcheck_condition_groups.add()
            item.lod = g.lod
            item.zone = g.zone
            item.condition = g.condition
            item.object_names = ", ".join(g.object_names)
            item.count = g.count
            item.is_duplicate = g.is_duplicate

        n_duplicate = sum(1 for g in groups if g.is_duplicate)
        self.report(
            {'WARNING'} if n_duplicate else {'INFO'},
            f"พบ {len(groups)} Condition Group | ซ้ำกัน (มีปัญหา) {n_duplicate} กลุ่ม",
        )
        return {'FINISHED'}


class DUPCHECK_UL_condition_groups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        header_row = col.row(align=True)
        header_row.alert = item.is_duplicate
        header_row.label(text="", icon='ERROR' if item.is_duplicate else 'CHECKMARK')
        header_row.label(text=f"VIS-{item.condition}  |  {item.lod}  |  {item.zone}  |  {item.count} ชิ้น")

        for name in item.object_names.split(", "):
            name_row = col.row(align=True)
            name_row.scale_y = 0.8
            name_row.alert = item.is_duplicate
            name_row.label(text=f"   • {name}")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        scene = context.scene
        flt_flags = [self.bitflag_filter_item] * len(items)

        lod_filter = scene.dupcheck_condgroup_lod_filter.strip().upper()
        only_duplicates = scene.dupcheck_condgroup_only_duplicates

        for idx, item in enumerate(items):
            show = True
            if lod_filter and lod_filter not in item.lod.upper():
                show = False
            if only_duplicates and not item.is_duplicate:
                show = False
            if not show:
                flt_flags[idx] &= ~self.bitflag_filter_item

        return flt_flags, []


# =====================================================================
# Operator: สแกนหา Object ที่มี .001 .002 ...
# =====================================================================
class DUPCHECK_OT_scan(Operator):
    bl_idname = "dupcheck.scan"
    bl_label = "Scan ชื่อผิดปกติ"
    bl_description = "สแกนหา Object ใน Collection (รวม Sub-collection) ที่ชื่อลงท้ายด้วย .001/.002... หรือมีอะไรเกินต่อท้าย LOD/MLOD ที่ถูกต้องอยู่แล้ว"

    def execute(self, context):
        scene = context.scene
        col = scene.dupcheck_collection

        if col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection ก่อน")
            return {'CANCELLED'}

        scene.dupcheck_items.clear()
        scene.dupcheck_merge_groups.clear()

        # -------- pass 1: หา object ที่เป็น duplicate จริง (Zone/Condition เหมือนกันทุกตัว) --------
        # แยกไปให้ merge เป็นกลุ่ม ไม่เอามาปนกับลิสต์เปลี่ยนชื่อทีละตัวด้านล่าง
        # รวม 2 แบบ: (1) ต่างกันแค่ .NNN ต่อท้าย (2) ต่างกันแค่มี/ไม่มี FDST
        merge_groups = find_mergeable_duplicate_groups(col) + find_fdst_duplicate_groups(col)
        skip_names = set()
        for g in merge_groups:
            item = scene.dupcheck_merge_groups.add()
            item.keep_name = g['keep']
            item.remove_names = ", ".join(g['remove'])
            item.remove_count = len(g['remove'])
            item.selected = True
            uv_match, uv_note = compare_uv_maps_in_group(g['keep'], g['remove'])
            item.uv_match = uv_match
            item.uv_note = uv_note
            skip_names.add(g['keep'])
            skip_names.update(g['remove'])

        existing_names = set(o.name for o in bpy.data.objects)
        found = find_duplicate_suffix_objects(col, skip_names=skip_names)
        # เรียง: ตัวที่มี zone แบบ ตัวอักษร+เลข (เช่น A1) ขึ้นก่อนเสมอ แล้วค่อยตามสาเหตุ แล้วตามชื่อ
        found.sort(key=lambda x: (not has_letter_digit_zone(x[0]), x[2], x[0]))

        # เช็คว่ามี 2 ตัวในชุดนี้เสนอชื่อเดียวกันหรือไม่
        # (เช่น ..._LOD0.001 กับ ..._LOD0_002 พอตัดส่วนเกินออกจะเหลือ ..._LOD0 เหมือนกันทั้งคู่)
        target_counts = {}
        for _, new_name, _ in found:
            target_counts[new_name] = target_counts.get(new_name, 0) + 1

        n_conflict = 0
        n_lod_excess = 0
        n_dot = 0
        n_lod_invalid = 0
        n_mlod_fix = 0
        n_lod_mlod_conflict = 0
        n_missing_fdst = 0
        n_fdst_glued = 0
        reason_labels = {
            "LOD_EXCESS": "มีส่วนเกินหลัง LOD",
            "DOT": "Blender auto-rename (.NNN)",
            "LOD_INVALID": f"LOD ไม่ใช่ตัวเลข - ใส่ {LOD_PLACEHOLDER} ไว้ให้ ต้องแก้เป็นเลขเองก่อน Rename",
            "MLOD_FIX": "MLOD ห้ามมีอะไรต่อท้าย (ไม่มีเลข) - แก้เป็น 'MLOD' เฉย ๆ ให้แล้ว",
            "LOD_MLOD_CONFLICT": "มีทั้ง LOD และ MLOD ในชื่อเดียวกัน - เลือกเองว่าจะเอาอันไหน แล้วลบอีกอันออกจากชื่อใหม่",
            "MISSING_FDST": "ไม่มี tag FDST เลย - แทรกก่อน ID-/VIS-/LOD/Base ให้แล้ว (เลือกไว้แล้ว แก้ตำแหน่งได้ถ้าไม่ตรง)",
            "FDST_GLUED": "FDST ติดกับตัวอักษรข้างเคียง ขาด _ คั่น - แทรก _ ให้ถูกตำแหน่งแล้ว",
        }
        for name, new_name, reason in found:
            conflict = (new_name in existing_names and new_name != name) or target_counts[new_name] > 1
            if conflict:
                n_conflict += 1
            if reason == "LOD_EXCESS":
                n_lod_excess += 1
            elif reason == "DOT":
                n_dot += 1
            elif reason == "LOD_INVALID":
                n_lod_invalid += 1
            elif reason == "MLOD_FIX":
                n_mlod_fix += 1
            elif reason == "LOD_MLOD_CONFLICT":
                n_lod_mlod_conflict += 1
            elif reason == "MISSING_FDST":
                n_missing_fdst += 1
            elif reason == "FDST_GLUED":
                n_fdst_glued += 1

            item = scene.dupcheck_items.add()
            item.name = name
            item.new_name = new_name
            item.reason = reason_labels.get(reason, reason)
            item.has_conflict = conflict
            item.needs_number = (reason == "LOD_INVALID")
            item.needs_choice = (reason == "LOD_MLOD_CONFLICT")
            # LOD_INVALID ยังมี $$$ ค้างอยู่ / LOD_MLOD_CONFLICT ยังไม่ได้เลือก -> ไม่ auto-select ต้องแก้เองก่อนเสมอ
            # MISSING_FDST / MLOD_FIX / LOD_EXCESS / DOT รู้คำตอบที่ถูกต้องแน่นอนอยู่แล้ว -> auto-select ให้เลย
            # (ช่อง 'ชื่อใหม่' ยังแก้ไขเองได้เสมอ ถ้าตำแหน่งที่เดาไม่ตรงกับที่ต้องการก็แก้แล้วค่อยกด Rename ได้)
            item.selected = (not conflict) and (reason not in ("LOD_INVALID", "LOD_MLOD_CONFLICT"))

        n_total = len(found)
        n_merge_groups = len(merge_groups)
        n_merge_removable = sum(len(g['remove']) for g in merge_groups)
        self.report(
            {'INFO'} if n_conflict == 0 else {'WARNING'},
            f"พบ {n_total} object ผิดปกติ (ไม่มี FDST {n_missing_fdst} | FDST ขาด _ {n_fdst_glued} | LOD เกิน {n_lod_excess} | .NNN {n_dot} "
            f"| MLOD มีเลขเกิน {n_mlod_fix} | LOD/MLOD ชนกัน {n_lod_mlod_conflict} | LOD ไม่ใช่เลข {n_lod_invalid}) "
            f"| พบ duplicate จริง {n_merge_groups} กลุ่ม (ลบได้ {n_merge_removable} object)"
            + (f"| ⚠ ชื่อใหม่จะชนกัน {n_conflict} ตัว (ไม่ auto-select)" if n_conflict else ""),
        )
        return {'FINISHED'}


# =====================================================================
# Operator: เลือกทั้งหมด / ไม่เลือกเลย / สลับ
# =====================================================================
class DUPCHECK_OT_select_all(Operator):
    bl_idname = "dupcheck.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.dupcheck_items:
            if not item.has_conflict and not item.needs_number and not item.needs_choice:
                item.selected = True
        return {'FINISHED'}


class DUPCHECK_OT_select_none(Operator):
    bl_idname = "dupcheck.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.dupcheck_items:
            item.selected = False
        return {'FINISHED'}


class DUPCHECK_OT_select_invert(Operator):
    bl_idname = "dupcheck.select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.dupcheck_items:
            if not item.has_conflict and not item.needs_number and not item.needs_choice:
                item.selected = not item.selected
        return {'FINISHED'}


# =====================================================================
# Operator: Rename จริง (เฉพาะตัวที่ติ๊กเลือกไว้)
# =====================================================================
class DUPCHECK_OT_apply(Operator):
    bl_idname = "dupcheck.apply"
    bl_label = "Rename ตามที่เลือก"
    bl_description = "เปลี่ยนชื่อ Object ที่ติ๊กเลือกไว้ จาก .NNN เป็น _NNN (Ctrl+Z ได้ถ้าพลาด)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        count = 0
        skipped = 0
        skipped_no_number = 0
        skipped_no_choice = 0
        renamed_objects = []

        for item in scene.dupcheck_items:
            if not item.selected:
                continue

            # กันเหนียวสุดท้าย: ถ้ายังมี $$$ ค้างอยู่ หรือยังมี LOD/MLOD ชนกัน ห้าม rename เด็ดขาด
            # ไม่ว่าจะติ๊กเลือกไว้ยังไงก็ตาม
            if LOD_PLACEHOLDER in item.new_name:
                skipped_no_number += 1
                continue
            if item.needs_choice:
                skipped_no_choice += 1
                continue

            obj = bpy.data.objects.get(item.name)
            if obj is None:
                skipped += 1
                continue

            # เช็คซ้ำจากสถานะจริง ณ ตอนกด กันชื่อชนที่เพิ่งเกิดขึ้นหลังสแกน
            clash = bpy.data.objects.get(item.new_name)
            if clash is not None and clash.name != obj.name:
                skipped += 1
                continue

            obj.name = item.new_name
            count += 1
            renamed_objects.append(obj)

        msg = f"Rename แล้ว {count} object"
        if skipped:
            msg += f" | ข้าม {skipped} (ชื่อชนกัน หรือหา object ไม่เจอ)"
        if skipped_no_number:
            msg += f" | ข้าม {skipped_no_number} (ยังไม่ได้ใส่เลข LOD แทน {LOD_PLACEHOLDER})"
        if skipped_no_choice:
            msg += f" | ข้าม {skipped_no_choice} (ยังไม่ได้เลือกว่าจะเอา LOD หรือ MLOD)"
        self.report({'INFO'}, msg)

        if renamed_objects:
            print(f"[Diamond Eyes] Rename ไปทั้งหมด {count} object:")
            for obj in renamed_objects:
                print(f"    - {obj.name}")

        # เลือก object ที่เพิ่งแก้ให้ใน viewport เห็นเลยว่าแก้ตัวไหนไปบ้าง
        bpy.ops.object.select_all(action='DESELECT')
        for obj in renamed_objects:
            obj.select_set(True)
        if renamed_objects:
            context.view_layer.objects.active = renamed_objects[0]

        bpy.ops.dupcheck.scan()  # สแกนใหม่ให้ตรงกับสถานะล่าสุด
        return {'FINISHED'}


# =====================================================================
# Operator: เลือกทั้งหมด/ไม่เลือกเลย สำหรับกลุ่ม Merge
# =====================================================================
class DUPCHECK_OT_merge_select_all(Operator):
    bl_idname = "dupcheck.merge_select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.dupcheck_merge_groups:
            item.selected = True
        return {'FINISHED'}


class DUPCHECK_OT_merge_select_none(Operator):
    bl_idname = "dupcheck.merge_select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.dupcheck_merge_groups:
            item.selected = False
        return {'FINISHED'}


# =====================================================================
# Operator: Merge duplicate จริง (ลบตัวซ้ำ เหลือไว้ตัวเดียว)
# =====================================================================
class DUPCHECK_OT_merge_apply(Operator):
    bl_idname = "dupcheck.merge_apply"
    bl_label = "Merge ที่เลือก"
    bl_description = (
        "Merge (join) เนื้อ Mesh ของ Object ที่ซ้ำกันจริง (Zone/Condition เหมือนกันทุกตัว) "
        "เข้ากับตัวหลักจริง ๆ ไม่ใช่แค่ลบทิ้ง (Ctrl+Z ได้ถ้าพลาด)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        merged_groups = 0
        joined_count = 0
        missing = 0
        skipped_hidden = 0
        kept_objects = []

        prev_selected = list(context.selected_objects)
        prev_active = context.view_layer.objects.active

        for group in scene.dupcheck_merge_groups:
            if not group.selected:
                continue

            keep_obj = bpy.data.objects.get(group.keep_name)
            if keep_obj is None or keep_obj.type != 'MESH':
                missing += 1
                continue

            # เช็คซ้ำจากสถานะจริง ณ ตอนกด (Zone/Condition ต้องยังตรงกันอยู่) กันเคสมีคนแก้ไปแล้ว
            remove_names = [n.strip() for n in group.remove_names.split(",") if n.strip()]
            keep_zc = (get_zone(keep_obj.name), get_condition(keep_obj.name))

            join_targets = []
            for rn in remove_names:
                robj = bpy.data.objects.get(rn)
                if robj is None or robj.type != 'MESH':
                    continue
                if (get_zone(robj.name), get_condition(robj.name)) != keep_zc:
                    continue  # เปลี่ยนไปแล้วไม่ตรงกันอีกต่อไป ข้ามอันนี้ไปเพื่อความปลอดภัย
                join_targets.append(robj)

            if not join_targets:
                continue

            # object ที่ถูกซ่อนอยู่ (ปิดตา/ปิด viewport/collection ปิด) join ไม่ได้ ต้องข้าม
            visible_targets = [o for o in join_targets if o.visible_get(view_layer=context.view_layer)]
            if len(visible_targets) < len(join_targets):
                skipped_hidden += (len(join_targets) - len(visible_targets))
            if not keep_obj.visible_get(view_layer=context.view_layer):
                skipped_hidden += len(visible_targets)
                continue
            if not visible_targets:
                continue

            # ตั้ง UV Map ตัวแรกสุดเป็น Active ให้ keep_obj ก่อน join (join จะรวมตาม UV ของ active object)
            set_active_uv_to_first(keep_obj)

            bpy.ops.object.select_all(action='DESELECT')
            for robj in visible_targets:
                robj.select_set(True)
            keep_obj.select_set(True)
            context.view_layer.objects.active = keep_obj

            try:
                bpy.ops.object.join()
            except RuntimeError as e:
                self.report({'ERROR'}, f"Merge '{keep_obj.name}' ไม่สำเร็จ: {e}")
                continue

            merged_groups += 1
            joined_count += len(visible_targets)

            # ถ้าตัวที่เก็บไว้เองก็ยังมี .NNN ติดอยู่ (ไม่มีตัว base เปล่าในกลุ่มเลย) เกลาชื่อให้สะอาดด้วย
            m = DOT_SUFFIX_PATTERN.match(keep_obj.name)
            if m:
                clean_name = m.group(1)
                if bpy.data.objects.get(clean_name) is None:
                    keep_obj.name = clean_name
            kept_objects.append(keep_obj)

        msg = f"Merge (join) แล้ว {merged_groups} กลุ่ม (รวม {joined_count} object เข้าตัวหลักจริง ๆ)"
        if missing:
            msg += f" | หา object เก็บไว้ไม่เจอ {missing} กลุ่ม"
        if skipped_hidden:
            msg += f" | ข้าม {skipped_hidden} ชิ้นเพราะถูกซ่อนอยู่ (เปิดตาก่อนแล้วลองใหม่)"
        self.report({'INFO'}, msg)

        # เลือก object ที่เก็บไว้ใน viewport ให้เห็นเลยว่า merge ตัวไหนไปบ้าง
        bpy.ops.object.select_all(action='DESELECT')
        for obj in kept_objects:
            obj.select_set(True)
        if kept_objects:
            context.view_layer.objects.active = kept_objects[-1]
        elif prev_active is not None and prev_active.name in bpy.data.objects:
            for obj in prev_selected:
                if obj.name in bpy.data.objects:
                    obj.select_set(True)
            context.view_layer.objects.active = prev_active

        bpy.ops.dupcheck.scan()  # สแกนใหม่ให้ตรงกับสถานะล่าสุด
        return {'FINISHED'}


# =====================================================================
# UIList
# =====================================================================
class DUPCHECK_UL_items(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        name_row = col.row(align=True)
        if item.needs_choice:
            name_row.alert = True
            name_row.label(text="", icon='QUESTION')
        elif item.needs_number:
            name_row.alert = True
            name_row.label(text="", icon='GREASEPENCIL')
        elif item.has_conflict:
            name_row.alert = True
            name_row.label(text="", icon='ERROR')
        else:
            name_row.prop(item, "selected", text="")

        name_row.label(text=item.name)
        copy_op = name_row.operator("diamondeyes.copy_name", text="", icon='COPYDOWN')
        copy_op.name_to_copy = item.name

        new_name_row = col.row(align=True)
        new_name_row.label(text="", icon='TRIA_RIGHT')
        if item.needs_choice or item.needs_number or item.has_conflict:
            new_name_row.alert = True
        new_name_row.prop(item, "new_name", text="")

        reason_row = col.row(align=True)
        reason_row.scale_y = 0.7
        if item.needs_choice:
            reason_row.alert = True
            reason_row.label(text="   ⚠ ลบ LOD หรือ MLOD ตัวที่ไม่ต้องการออกจากชื่อใหม่เอง ไม่งั้นกด Rename แล้วจะถูกข้าม")
        elif item.needs_number:
            reason_row.alert = True
            reason_row.label(text=f"   ⚠ แก้ {LOD_PLACEHOLDER} เป็นเลข LOD จริงก่อน ไม่งั้นกด Rename แล้วจะถูกข้าม")
        elif item.has_conflict:
            reason_row.alert = True
            reason_row.label(text=f"   ⚠ ชื่อ '{item.new_name}' มีอยู่แล้วในฉาก - แก้ชื่อใหม่ในช่องบน หรือหา/ลบ/merge ตัวที่ชนกันก่อน")
            copy_conflict_op = reason_row.operator("diamondeyes.copy_name", text="", icon='COPYDOWN')
            copy_conflict_op.name_to_copy = item.new_name
            select_conflict_op = reason_row.operator("diamondeyes.select_object", text="", icon='RESTRICT_SELECT_OFF')
            select_conflict_op.name_to_select = item.new_name
        else:
            reason_row.label(text=f"   สาเหตุ: {item.reason}")


# =====================================================================
# UIList - กลุ่ม duplicate ที่จะ Merge
# =====================================================================
class DUPCHECK_UL_merge_groups(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)
        row = col.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=item.keep_name, icon='CHECKMARK')
        if not item.uv_match:
            row.alert = True
            row.label(text="", icon='UV')

        count_row = col.row(align=True)
        count_row.scale_y = 0.8
        count_row.label(text=f"   จะลบ {item.remove_count} ตัว:")

        # แยกชื่อ object ที่จะลบแต่ละตัวลงมาทีละบรรทัด กันชื่อยาวๆ วิ่งเลยขอบจนอ่านไม่เห็น
        remove_names = [n.strip() for n in item.remove_names.split(",") if n.strip()]
        for remove_name in remove_names:
            remove_row = col.row(align=True)
            remove_row.scale_y = 0.8
            remove_row.label(text=f"      • {remove_name}")

        if not item.uv_match:
            uv_row = col.row(align=True)
            uv_row.scale_y = 0.8
            uv_row.alert = True
            uv_row.label(text=f"   ⚠ {item.uv_note}")
        else:
            uv_ok_row = col.row(align=True)
            uv_ok_row.scale_y = 0.8
            uv_ok_row.label(text="   ✓ UV Map ตรงกันทุกตัว - จะตั้ง UV แรกสุดเป็น Active ให้อัตโนมัติตอน Merge")


# =====================================================================
# ================  UV MAP INSPECTOR / EDITOR (แท็บย่อยที่ 4)  ================
# =====================================================================
# เลือกกลุ่ม Object เป้าหมาย (จาก Selection ในวิวพอร์ต หรือจาก Collection) แล้ว:
#   - สแกนดูว่าแต่ละ Object มี UV Map อะไรอยู่บ้าง และตัวไหนเป็น Active
#   - เทียบกับ pattern ของ UV Map ที่พบบ่อยที่สุดในกลุ่ม เพื่อบอกว่าตัวไหน "เหมือนส่วนใหญ่"
#     ตัวไหน "ต่างจากส่วนใหญ่" (ขาด/เกิน UV Map อะไรไปบ้าง)
#   - ตั้งเป็น Active, เพิ่ม, หรือลบ UV Map ตามชื่อที่กำหนด ให้ Object ที่ติ๊กเลือกไว้ทีเดียว
# =====================================================================

class UvMapInfoItem(PropertyGroup):
    name: StringProperty(name="Object Name")
    uv_names: StringProperty(name="UV Map ทั้งหมด", default="")
    active_uv: StringProperty(name="Active UV", default="")
    matches_common: BoolProperty(name="ตรงกับส่วนใหญ่", default=True)
    diff_note: StringProperty(name="ความต่างจากส่วนใหญ่", default="")
    selected: BoolProperty(name="เลือก", default=True)


# =====================================================================
# Operator: สแกน UV Map ของ Object เป้าหมาย
# =====================================================================
class UVTOOL_OT_scan(Operator):
    bl_idname = "uvtool.scan"
    bl_label = "สแกน UV Map"
    bl_description = "เช็ค UV Map ทั้งหมดที่มีอยู่ในแต่ละ Object เป้าหมาย พร้อมเทียบว่าเหมือน/ต่างจากส่วนใหญ่ยังไง"

    def execute(self, context):
        scene = context.scene

        if scene.uvtool_target_mode == 'COLLECTION':
            col = scene.uvtool_collection
            if col is None:
                self.report({'WARNING'}, "กรุณาเลือก Collection ก่อน")
                return {'CANCELLED'}
            targets = [o for o in col.all_objects if o.type == 'MESH']
            bpy.ops.object.select_all(action='DESELECT')
            for obj in targets:
                obj.select_set(True)
        else:
            targets = [o for o in context.selected_objects if o.type == 'MESH']

        if not targets:
            self.report({'WARNING'}, "ไม่มี Mesh Object เป้าหมาย (เลือก Object ในวิวพอร์ต หรือเลือก Collection ก่อน)")
            return {'CANCELLED'}

        scene.uvtool_map_items.clear()

        raw = []
        for obj in targets:
            names = [l.name for l in obj.data.uv_layers]
            active = obj.data.uv_layers.active.name if obj.data.uv_layers.active else ""
            raw.append((obj.name, names, active))

        # หา pattern ของชุด UV Map ที่พบบ่อยที่สุดในกลุ่มนี้ ใช้เป็นตัวเทียบว่า "เหมือน/ต่าง"
        pattern_counts = {}
        for _, names, _ in raw:
            key = frozenset(names)
            pattern_counts[key] = pattern_counts.get(key, 0) + 1
        common_pattern = max(pattern_counts, key=pattern_counts.get) if pattern_counts else frozenset()

        raw.sort(key=lambda x: x[0])

        for obj_name, names, active in raw:
            item = scene.uvtool_map_items.add()
            item.name = obj_name
            item.uv_names = ", ".join(names) if names else "(ไม่มี UV Map เลย)"
            item.active_uv = active if active else "-"
            item.selected = True

            this_set = frozenset(names)
            if this_set == common_pattern:
                item.matches_common = True
                item.diff_note = ""
            else:
                item.matches_common = False
                missing = common_pattern - this_set
                extra = this_set - common_pattern
                parts = []
                if missing:
                    parts.append(f"ขาด: {', '.join(sorted(missing))}")
                if extra:
                    parts.append(f"เกิน: {', '.join(sorted(extra))}")
                item.diff_note = " | ".join(parts) if parts else "ต่างจากส่วนใหญ่"

        n_total = len(raw)
        n_diff = sum(1 for _, names, _ in raw if frozenset(names) != common_pattern)
        common_str = ", ".join(sorted(common_pattern)) if common_pattern else "(ไม่มี)"
        self.report(
            {'INFO'} if n_diff == 0 else {'WARNING'},
            f"สแกน {n_total} object | UV ที่พบบ่อยสุด: {common_str}"
            + (f" | ต่างจากส่วนใหญ่ {n_diff} ชิ้น" if n_diff else ""),
        )
        return {'FINISHED'}


# =====================================================================
# Operator: เลือกทั้งหมด / ไม่เลือกเลย / สลับ / เลือกเฉพาะที่ต่างจากส่วนใหญ่
# =====================================================================
class UVTOOL_OT_select_all(Operator):
    bl_idname = "uvtool.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.uvtool_map_items:
            item.selected = True
        return {'FINISHED'}


class UVTOOL_OT_select_none(Operator):
    bl_idname = "uvtool.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.uvtool_map_items:
            item.selected = False
        return {'FINISHED'}


class UVTOOL_OT_select_invert(Operator):
    bl_idname = "uvtool.select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.uvtool_map_items:
            item.selected = not item.selected
        return {'FINISHED'}


class UVTOOL_OT_select_diff(Operator):
    bl_idname = "uvtool.select_diff"
    bl_label = "เลือกเฉพาะที่ต่างจากส่วนใหญ่"
    bl_description = "เลือกเฉพาะ Object ที่มีชุด UV Map ต่างจากที่พบบ่อยที่สุดในกลุ่ม"

    def execute(self, context):
        for item in context.scene.uvtool_map_items:
            item.selected = not item.matches_common
        return {'FINISHED'}


# =====================================================================
# Operator: ตั้งเป็น Active / เพิ่ม / ลบ UV Map ตามชื่อ (เฉพาะที่ติ๊กเลือกไว้)
# =====================================================================
class UVTOOL_OT_set_active(Operator):
    bl_idname = "uvtool.set_active"
    bl_label = "ตั้งเป็น Active ตามชื่อ"
    bl_description = "ตั้ง UV Map ตามชื่อที่กำหนดเป็น Active (และ Active Render) ให้ Object ที่ติ๊กเลือกไว้ (เฉพาะตัวที่มี UV Map นี้อยู่แล้ว)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target_name = scene.uvtool_target_name.strip()
        if not target_name:
            self.report({'WARNING'}, "กรุณาพิมพ์ชื่อ UV Map ก่อน")
            return {'CANCELLED'}

        count = 0
        skipped = 0
        for item in scene.uvtool_map_items:
            if not item.selected:
                continue
            obj = bpy.data.objects.get(item.name)
            if obj is None or obj.type != 'MESH' or obj.data is None:
                skipped += 1
                continue
            layer = obj.data.uv_layers.get(target_name)
            if layer is None:
                skipped += 1
                continue
            obj.data.uv_layers.active = layer
            layer.active_render = True
            count += 1

        msg = f"ตั้ง Active '{target_name}' ให้ {count} object"
        if skipped:
            msg += f" | ข้าม {skipped} (ไม่มี UV Map นี้)"
        self.report({'INFO'} if skipped == 0 else {'WARNING'}, msg)
        bpy.ops.uvtool.scan()
        return {'FINISHED'}


class UVTOOL_OT_add_uv(Operator):
    bl_idname = "uvtool.add_uv"
    bl_label = "เพิ่ม UV Map ตามชื่อ"
    bl_description = "สร้าง UV Map ใหม่ตามชื่อที่กำหนด ให้ Object ที่ติ๊กเลือกไว้ที่ยังไม่มี UV Map ชื่อนี้"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target_name = scene.uvtool_target_name.strip()
        if not target_name:
            self.report({'WARNING'}, "กรุณาพิมพ์ชื่อ UV Map ก่อน")
            return {'CANCELLED'}

        count = 0
        skipped = 0
        for item in scene.uvtool_map_items:
            if not item.selected:
                continue
            obj = bpy.data.objects.get(item.name)
            if obj is None or obj.type != 'MESH' or obj.data is None:
                skipped += 1
                continue
            if obj.data.uv_layers.get(target_name) is not None:
                skipped += 1  # มีอยู่แล้ว ไม่เพิ่มซ้ำ
                continue
            obj.data.uv_layers.new(name=target_name)
            count += 1

        msg = f"เพิ่ม UV Map '{target_name}' ให้ {count} object"
        if skipped:
            msg += f" | ข้าม {skipped} (มีอยู่แล้ว หรือไม่ใช่ mesh)"
        self.report({'INFO'}, msg)
        bpy.ops.uvtool.scan()
        return {'FINISHED'}


class UVTOOL_OT_remove_uv(Operator):
    bl_idname = "uvtool.remove_uv"
    bl_label = "ลบ UV Map ตามชื่อ"
    bl_description = "ลบ UV Map ตามชื่อที่กำหนด ออกจาก Object ที่ติ๊กเลือกไว้ (จะไม่ลบถ้าเหลือ UV Map สุดท้ายเพียงอันเดียว)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        target_name = scene.uvtool_target_name.strip()
        if not target_name:
            self.report({'WARNING'}, "กรุณาพิมพ์ชื่อ UV Map ก่อน")
            return {'CANCELLED'}

        count = 0
        skipped = 0
        skipped_last = 0
        for item in scene.uvtool_map_items:
            if not item.selected:
                continue
            obj = bpy.data.objects.get(item.name)
            if obj is None or obj.type != 'MESH' or obj.data is None:
                skipped += 1
                continue
            layer = obj.data.uv_layers.get(target_name)
            if layer is None:
                skipped += 1
                continue
            if len(obj.data.uv_layers) <= 1:
                skipped_last += 1  # ห้ามลบ UV Map สุดท้าย
                continue
            obj.data.uv_layers.remove(layer)
            count += 1

        msg = f"ลบ UV Map '{target_name}' จาก {count} object"
        if skipped:
            msg += f" | ข้าม {skipped} (ไม่มี UV Map นี้)"
        if skipped_last:
            msg += f" | ข้าม {skipped_last} (เหลือ UV Map เดียว ลบไม่ได้)"
        self.report({'INFO'}, msg)
        bpy.ops.uvtool.scan()
        return {'FINISHED'}


# =====================================================================
# UIList
# =====================================================================
class UVTOOL_UL_map_items(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        col = layout.column(align=True)

        name_row = col.row(align=True)
        name_row.prop(item, "selected", text="")
        if not item.matches_common:
            name_row.alert = True
            name_row.label(text="", icon='ERROR')
        name_row.label(text=item.name)
        copy_op = name_row.operator("diamondeyes.copy_name", text="", icon='COPYDOWN')
        copy_op.name_to_copy = item.name

        detail_row = col.row(align=True)
        detail_row.scale_y = 0.8
        detail_row.label(text=f"   UV: {item.uv_names}  |  Active: {item.active_uv}")

        if not item.matches_common and item.diff_note:
            diff_row = col.row(align=True)
            diff_row.scale_y = 0.8
            diff_row.alert = True
            diff_row.label(text=f"   ⚠ {item.diff_note}")

    def filter_items(self, context, data, propname):
        items = getattr(data, propname)
        flt_flags = [self.bitflag_filter_item] * len(items)
        for idx, item in enumerate(items):
            show = True
            if self.filter_name and self.filter_name.lower() not in item.name.lower():
                show = False
            if not show:
                flt_flags[idx] &= ~self.bitflag_filter_item
        return flt_flags, []


# =====================================================================
# ================  SPLIT BY MATERIAL (แท็บย่อยที่ 5)  ================
# =====================================================================
# แยก Object ตาม Material (bpy.ops.mesh.separate type='MATERIAL') ออกเป็นชิ้นย่อย
# ย้ายชิ้นที่แยกออกมาไปเก็บใน Collection ต่างหาก ตั้งชื่อใหม่ไม่ให้ชนของเดิม แล้วจำ
# "ตัวหลักเดิม" ไว้ผ่าน custom property (ไม่พึ่งชื่อ object เลย เผื่อโดนเปลี่ยนชื่อทีหลัง)
# เพื่อให้กด Merge กลับเข้าตัวหลักได้แม่นยำ โดยใช้ join จริงเหมือน Check & Rename Duplicate
# =====================================================================

SPLITMAT_PARENT_KEY = "diamond_eyes_split_parent"
DEFAULT_SPLIT_COLLECTION_NAME = "Diamond Eyes - Split"


class MaterialSelectItem(PropertyGroup):
    name: StringProperty(name="Material Name")
    obj_count: IntProperty(name="จำนวน Object ที่ใช้", default=0)
    selected: BoolProperty(name="เลือก", default=True)


# =====================================================================
# Operator: สแกนหา Material ทั้งหมดที่ใช้อยู่จริงใน Object เป้าหมาย
# =====================================================================
class SPLITMAT_OT_scan_materials(Operator):
    bl_idname = "splitmat.scan_materials"
    bl_label = "สแกน Material"
    bl_description = "เช็คว่า Object เป้าหมายมี Material อะไรใช้อยู่จริงบ้าง (มีหน้าใช้จริง) ให้เลือกว่าจะ Split อันไหน"

    def execute(self, context):
        scene = context.scene

        targets = [o for o in context.selected_objects if o.type == 'MESH']

        if not targets:
            self.report({'WARNING'}, "ไม่มี Mesh Object เป้าหมาย (เลือก Object ในวิวพอร์ตก่อน)")
            return {'CANCELLED'}

        mat_counts = {}
        for obj in targets:
            if obj.data is None:
                continue
            used_indices = {p.material_index for p in obj.data.polygons}
            mat_names_used = set()
            for i in used_indices:
                if 0 <= i < len(obj.material_slots) and obj.material_slots[i].material:
                    mat_names_used.add(obj.material_slots[i].material.name)
            for name in mat_names_used:
                mat_counts[name] = mat_counts.get(name, 0) + 1

        old_selection = {m.name: m.selected for m in scene.splitmat_materials}
        scene.splitmat_materials.clear()
        for name in sorted(mat_counts):
            item = scene.splitmat_materials.add()
            item.name = name
            item.obj_count = mat_counts[name]
            item.selected = old_selection.get(name, True)  # คงค่าที่ติ๊กไว้เดิมถ้าสแกนซ้ำ

        if mat_counts:
            self.report({'INFO'}, f"พบ {len(mat_counts)} Material จาก {len(targets)} object")
        else:
            self.report({'WARNING'}, "ไม่พบ Material ที่มีหน้าใช้งานจริงเลยใน Object เป้าหมาย")
        return {'FINISHED'}


class SPLITMAT_OT_materials_select_all(Operator):
    bl_idname = "splitmat.materials_select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.splitmat_materials:
            item.selected = True
        return {'FINISHED'}


class SPLITMAT_OT_materials_select_none(Operator):
    bl_idname = "splitmat.materials_select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.splitmat_materials:
            item.selected = False
        return {'FINISHED'}


class SPLITMAT_OT_materials_select_invert(Operator):
    bl_idname = "splitmat.materials_select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.splitmat_materials:
            item.selected = not item.selected
        return {'FINISHED'}


class SPLITMAT_UL_materials(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=item.name, icon='MATERIAL')
        row.label(text=f"{item.obj_count} object")


def get_or_create_subcollection(parent_col, name):
    """หา Sub-collection ชื่อนี้ใน parent_col ถ้ายังไม่มีก็สร้างใหม่ให้"""
    for child in parent_col.children:
        if child.name == name:
            return child
    new_col = bpy.data.collections.new(name)
    parent_col.children.link(new_col)
    return new_col


class SPLITMAT_OT_split(Operator):
    bl_idname = "splitmat.split"
    bl_label = "Split by Material"
    bl_description = (
        "แยก Object ตาม Material ที่เลือกไว้ ลบ Material Slot ที่ไม่ได้ใช้ออกจากชิ้นที่แยก "
        "แล้วเก็บไว้ใน Sub-collection ตามชื่อ Material ภายใต้ Collection ปลายทาง"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene

        chosen_names = {m.name for m in scene.splitmat_materials if m.selected}
        if not chosen_names:
            self.report({'WARNING'}, "กรุณากด 'สแกน Material' แล้วติ๊กเลือก Material ที่ต้องการ Split ก่อน")
            return {'CANCELLED'}

        targets = [o for o in context.selected_objects if o.type == 'MESH']

        if not targets:
            self.report({'WARNING'}, "ไม่มี Mesh Object เป้าหมาย (เลือก Object ในวิวพอร์ต หรือเลือก Collection ก่อน)")
            return {'CANCELLED'}

        dest_name = scene.splitmat_collection_name.strip() or DEFAULT_SPLIT_COLLECTION_NAME
        dest_col = bpy.data.collections.get(dest_name)
        if dest_col is None:
            dest_col = bpy.data.collections.new(dest_name)
            context.scene.collection.children.link(dest_col)

        total_split = 0
        skipped_no_chosen_mat = 0
        skipped_hidden = 0
        skipped_no_material = 0
        skipped_single_material = 0

        for obj in targets:
            if obj.data is None:
                continue

            # นับ Material ที่ "ใช้งานจริง" (มีหน้าใช้) ในเนื้อ mesh ทั้งหมด ไม่ใช่แค่ตัวที่เลือกไว้
            used_mat_names = set()
            for p in obj.data.polygons:
                idx = p.material_index
                if 0 <= idx < len(obj.material_slots) and obj.material_slots[idx].material:
                    used_mat_names.add(obj.material_slots[idx].material.name)

            if len(used_mat_names) == 0:
                skipped_no_material += 1
                continue
            if len(used_mat_names) == 1:
                skipped_single_material += 1
                continue

            # เอาเฉพาะ Material ที่เลือกไว้ "และ" ใช้งานจริงใน object นี้
            slot_by_name = {s.material.name: i for i, s in enumerate(obj.material_slots) if s.material}
            mats_to_split = [name for name in chosen_names if name in used_mat_names]
            if not mats_to_split:
                skipped_no_chosen_mat += 1
                continue
            if not obj.visible_get(view_layer=context.view_layer):
                skipped_hidden += 1
                continue

            # แยกทีละ Material ที่เลือกไว้ (ตัวที่ไม่ได้เลือกจะยังรวมอยู่ใน object หลักตามเดิม)
            for mat_name in mats_to_split:
                slot_index = slot_by_name.get(mat_name)
                if slot_index is None or slot_index >= len(obj.material_slots):
                    continue  # index อาจขยับหลัง separate รอบก่อนหน้า ถ้าไม่เจอแล้วก็ข้าม

                before_names = set(bpy.data.objects.keys())

                bpy.ops.object.select_all(action='DESELECT')
                obj.select_set(True)
                context.view_layer.objects.active = obj
                bpy.ops.object.mode_set(mode='EDIT')
                bpy.ops.mesh.select_all(action='DESELECT')
                obj.active_material_index = slot_index
                bpy.ops.object.material_slot_select()
                bpy.ops.mesh.separate(type='SELECTED')
                bpy.ops.object.mode_set(mode='OBJECT')

                after_names = set(bpy.data.objects.keys())
                new_names = after_names - before_names
                if not new_names:
                    continue  # material นี้ไม่มีหน้าจริงให้แยก (ไม่ควรเกิดขึ้นถ้าสแกนถูกต้อง)

                new_obj = bpy.data.objects[new_names.pop()]

                # ลบ Material Slot ที่ไม่ได้ใช้ออกจากชิ้นที่เพิ่ง split (เหลือแค่ material ที่แยกมาจริง ๆ)
                bpy.ops.object.select_all(action='DESELECT')
                new_obj.select_set(True)
                context.view_layer.objects.active = new_obj
                try:
                    bpy.ops.object.material_slot_remove_unused()
                except RuntimeError:
                    pass  # ไม่ critical พอจะหยุดทั้งขั้นตอน ข้ามไปได้

                base_new_name = f"{obj.name}_SPLITMAT-{mat_name}"
                final_name = base_new_name
                n = 1
                while bpy.data.objects.get(final_name) is not None and bpy.data.objects.get(final_name) is not new_obj:
                    final_name = f"{base_new_name}_{n}"
                    n += 1
                new_obj.name = final_name

                # จำตัวหลักเดิมไว้ผ่าน custom property (ไม่พึ่งชื่อเลย กัน merge กลับผิดตัวถ้ามีคนเปลี่ยนชื่อทีหลัง)
                new_obj[SPLITMAT_PARENT_KEY] = obj.name

                # ย้ายเข้า sub-collection ที่ตั้งชื่อตาม Material นี้ (สร้างให้ถ้ายังไม่มี) อยู่ใต้ Collection ปลายทาง
                mat_col = get_or_create_subcollection(dest_col, mat_name)
                for c in list(new_obj.users_collection):
                    c.objects.unlink(new_obj)
                mat_col.objects.link(new_obj)

                total_split += 1

                # slot_by_name อาจเพี้ยนหลัง separate (slot index ขยับ) -> สร้างใหม่จากของจริงก่อนไปรอบถัดไป
                slot_by_name = {s.material.name: i for i, s in enumerate(obj.material_slots) if s.material}

        msg = f"Split by Material แล้ว {total_split} ชิ้น ({len(chosen_names)} Material ที่เลือก) เข้า Collection '{dest_name}'"
        if skipped_no_material:
            msg += f" | ⚠ ข้าม {skipped_no_material} object (ไม่มี Material เลย)"
        if skipped_single_material:
            msg += f" | ⚠ ข้าม {skipped_single_material} object (มี Material เดียว ไม่ต้อง split)"
        if skipped_no_chosen_mat:
            msg += f" | ข้าม {skipped_no_chosen_mat} object (ไม่มี Material ที่เลือกไว้เลย)"
        if skipped_hidden:
            msg += f" | ข้าม {skipped_hidden} ชิ้นเพราะถูกซ่อนอยู่"
        self.report(
            {'WARNING'} if (skipped_no_material or skipped_single_material) else {'INFO'},
            msg,
        )
        return {'FINISHED'}


class SPLITMAT_OT_merge_back(Operator):
    bl_idname = "splitmat.merge_back"
    bl_label = "Merge กลับเข้าตัวหลัก"
    bl_description = "Merge (join) ชิ้นที่เคย Split by Material ไว้ใน Collection ปลายทาง กลับเข้าตัวหลักที่มันแยกมาจากจริง ๆ"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        dest_name = scene.splitmat_collection_name.strip() or DEFAULT_SPLIT_COLLECTION_NAME
        dest_col = bpy.data.collections.get(dest_name)
        if dest_col is None:
            self.report({'WARNING'}, f"ไม่พบ Collection '{dest_name}'")
            return {'CANCELLED'}

        groups = {}
        for obj in list(dest_col.all_objects):
            parent_name = obj.get(SPLITMAT_PARENT_KEY)
            if not parent_name:
                continue
            groups.setdefault(parent_name, []).append(obj)

        if not groups:
            self.report({'WARNING'}, f"ไม่พบชิ้นที่เคย Split ไว้ใน Collection '{dest_name}'")
            return {'CANCELLED'}

        merged_groups = 0
        joined_count = 0
        missing_parent = 0
        skipped_hidden = 0

        for parent_name, pieces in groups.items():
            parent_obj = bpy.data.objects.get(parent_name)
            if parent_obj is None or parent_obj.type != 'MESH':
                missing_parent += 1
                continue

            visible_pieces = [o for o in pieces if o.visible_get(view_layer=context.view_layer)]
            skipped_hidden += (len(pieces) - len(visible_pieces))
            if not visible_pieces:
                continue
            if not parent_obj.visible_get(view_layer=context.view_layer):
                skipped_hidden += len(visible_pieces)
                continue

            set_active_uv_to_first(parent_obj)

            bpy.ops.object.select_all(action='DESELECT')
            for o in visible_pieces:
                o.select_set(True)
            parent_obj.select_set(True)
            context.view_layer.objects.active = parent_obj

            try:
                bpy.ops.object.join()
            except RuntimeError as e:
                self.report({'ERROR'}, f"Merge กลับ '{parent_name}' ไม่สำเร็จ: {e}")
                continue

            merged_groups += 1
            joined_count += len(visible_pieces)

        msg = f"Merge กลับแล้ว {merged_groups} กลุ่ม (รวม {joined_count} ชิ้นกลับเข้าตัวหลัก)"
        if missing_parent:
            msg += f" | หา object หลักไม่เจอ {missing_parent} กลุ่ม"
        if skipped_hidden:
            msg += f" | ข้าม {skipped_hidden} ชิ้นเพราะถูกซ่อนอยู่"
        self.report({'INFO'}, msg)
        return {'FINISHED'}


# =====================================================================
# ================  SORT DEBRIS COLLECTION (แท็บย่อยที่ 6)  ================
# =====================================================================
# เช็คชื่อ Sub-collection (ไม่ใช่ mesh/object ข้างในเลย) ว่าลงท้ายด้วย _dbr_## (## = ตัวเลข) ไหม
# แล้วจัดลำดับ Sub-collection ใหม่ตามเลขนั้น (น้อยไปมาก/มากไปน้อย) โดย unlink แล้ว link กลับเข้า
# Collection หลักตามลำดับที่ต้องการ - ไม่มีการเปลี่ยนชื่อใด ๆ ทั้งสิ้น
# Sub-collection ที่ไม่มี _dbr_## หรือรูปแบบไม่ถูกต้อง จะถูกข้ามและแจ้งจำนวนให้เสมอ
# =====================================================================

DBR_SUFFIX_PATTERN = re.compile(r'_dbr_(\d+)$', re.IGNORECASE)


def _on_sortdbr_direction_update(self, context):
    # สลับทิศทางเรียงแล้ว สแกนใหม่ให้ทันที ถ้าเลือก Collection หลักไว้แล้ว
    if context.scene.sortdbr_collection is not None:
        bpy.ops.sortdbr.scan()


class DebrisItem(PropertyGroup):
    name: StringProperty(name="Collection Name")
    current_number: IntProperty(name="เลข dbr", default=0)
    selected: BoolProperty(name="เลือก", default=True)


# =====================================================================
# Operator: สแกนหา Sub-collection ที่ชื่อมี _dbr_## แล้วคำนวณลำดับที่ควรเป็น
# =====================================================================
class SORTDBR_OT_scan(Operator):
    bl_idname = "sortdbr.scan"
    bl_label = "สแกน Sub-collection"
    bl_description = "เช็คชื่อ Sub-collection (ไม่ใช่ mesh ข้างใน) ว่ามี _dbr_## ถูกต้องกี่ตัว แล้วเรียงลำดับตามที่เลือก"

    def execute(self, context):
        scene = context.scene
        parent_col = scene.sortdbr_collection
        if parent_col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection หลักก่อน")
            return {'CANCELLED'}

        scene.sortdbr_items.clear()

        valid = []
        invalid_count = 0
        for child in parent_col.children:
            m = DBR_SUFFIX_PATTERN.search(child.name)
            if m:
                valid.append((child.name, int(m.group(1))))
            else:
                invalid_count += 1

        reverse = (scene.sortdbr_direction == 'DESC')
        valid.sort(key=lambda x: x[1], reverse=reverse)

        for name, num in valid:
            item = scene.sortdbr_items.add()
            item.name = name
            item.current_number = num
            item.selected = True

        scene.sortdbr_invalid_count = invalid_count

        self.report(
            {'INFO'} if invalid_count == 0 else {'WARNING'},
            f"พบ {len(valid)} Sub-collection ที่มี dbr_## ถูกต้อง"
            + (f" | ข้าม {invalid_count} ตัว (ชื่อไม่มี dbr_## หรือรูปแบบไม่ถูกต้อง)" if invalid_count else ""),
        )
        return {'FINISHED'}


class SORTDBR_OT_select_all(Operator):
    bl_idname = "sortdbr.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.sortdbr_items:
            item.selected = True
        return {'FINISHED'}


class SORTDBR_OT_select_none(Operator):
    bl_idname = "sortdbr.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.sortdbr_items:
            item.selected = False
        return {'FINISHED'}


class SORTDBR_OT_select_invert(Operator):
    bl_idname = "sortdbr.select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.sortdbr_items:
            item.selected = not item.selected
        return {'FINISHED'}


class SORTDBR_UL_items(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=f"#{item.current_number}")
        row.label(text=item.name, icon='OUTLINER_COLLECTION')


# =====================================================================
# Operator: จัดเรียงลำดับ Sub-collection จริง (เฉพาะที่ติ๊กเลือกไว้) - ไม่เปลี่ยนชื่อเลย
# unlink แล้ว link กลับเข้า parent ตามลำดับที่ต้องการ (Blender เก็บลำดับการ link ไว้แสดงใน Outliner)
# =====================================================================
class SORTDBR_OT_apply(Operator):
    bl_idname = "sortdbr.apply"
    bl_label = "จัดเรียงลำดับ"
    bl_description = "จัดลำดับ Sub-collection ที่ติ๊กเลือกไว้ใหม่ตามเลข _dbr_## - ไม่เปลี่ยนชื่อใด ๆ เลย (Ctrl+Z ได้ถ้าพลาด)"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        parent_col = scene.sortdbr_collection
        if parent_col is None:
            self.report({'WARNING'}, "กรุณาเลือก Collection หลักก่อน")
            return {'CANCELLED'}

        # ลำดับเป้าหมายมาจากลิสต์ preview (เรียงไว้แล้วตอนสแกน) เฉพาะตัวที่ติ๊กเลือกไว้
        ordered_cols = []
        for item in scene.sortdbr_items:
            if not item.selected:
                continue
            col = bpy.data.collections.get(item.name)
            if col is None or col.name not in parent_col.children:
                continue
            ordered_cols.append(col)

        if not ordered_cols:
            self.report({'WARNING'}, "ไม่มี Sub-collection ที่เลือกไว้ (หรือยังไม่ได้สแกน)")
            return {'CANCELLED'}

        # unlink ตัวที่เลือกไว้ทั้งหมดออกจาก parent ก่อน แล้ว link กลับเข้าไปใหม่ตามลำดับที่ต้องการ
        # (การ link ใหม่จะต่อท้ายลำดับปัจจุบันเสมอ ไม่กระทบ sub-collection อื่นที่ไม่ได้เลือกไว้)
        for col in ordered_cols:
            parent_col.children.unlink(col)
        for col in ordered_cols:
            parent_col.children.link(col)

        self.report({'INFO'}, f"จัดเรียงลำดับแล้ว {len(ordered_cols)} Sub-collection (ไม่มีการเปลี่ยนชื่อใด ๆ)")
        bpy.ops.sortdbr.scan()  # สแกนใหม่ให้ตรงกับสถานะล่าสุด
        return {'FINISHED'}


# =====================================================================
# ================  REPLACE MATERIAL (แท็บย่อยที่ 7)  ================
# =====================================================================
# เลือก Object ในวิวพอร์ต -> เลือก Material ปลายทาง (ที่จะใช้แทนที่) -> สแกนหา Material
# ที่ใช้งานจริงในกลุ่มนั้น -> ติ๊กเลือก Material ที่จะถูกแทนที่ -> กด apply
# ทำงานที่ระดับ Material Slot โดยตรง (slot.material = ปลายทาง) ไม่แตะเนื้อ Mesh เลย
# ไม่ใช่การลบ Material ใด ๆ - เป็นการสลับการอ้างอิงเท่านั้น (Material เดิมยังอยู่ใน .blend ตามปกติ)
# =====================================================================

class REPLACEMAT_OT_scan(Operator):
    bl_idname = "replacemat.scan"
    bl_label = "สแกน Material"
    bl_description = "เช็คว่า Object ที่เลือกอยู่มี Material อะไรใช้งานจริงบ้าง (ไม่รวม Material ปลายทางที่เลือกไว้)"

    def execute(self, context):
        scene = context.scene
        targets = [o for o in context.selected_objects if o.type == 'MESH']

        if not targets:
            self.report({'WARNING'}, "ไม่มี Mesh Object เป้าหมาย (เลือก Object ในวิวพอร์ตก่อน)")
            return {'CANCELLED'}

        target_mat_name = scene.replacemat_target_material.name if scene.replacemat_target_material else None

        mat_counts = {}
        for obj in targets:
            if obj.data is None:
                continue
            used_indices = {p.material_index for p in obj.data.polygons}
            mat_names_used = set()
            for i in used_indices:
                if 0 <= i < len(obj.material_slots) and obj.material_slots[i].material:
                    mat_names_used.add(obj.material_slots[i].material.name)
            for name in mat_names_used:
                mat_counts[name] = mat_counts.get(name, 0) + 1

        # Material ปลายทางเอง ไม่ต้องให้เลือกมาแทนที่ตัวเอง
        if target_mat_name in mat_counts:
            del mat_counts[target_mat_name]

        old_selection = {m.name: m.selected for m in scene.replacemat_materials}
        scene.replacemat_materials.clear()
        for name in sorted(mat_counts):
            item = scene.replacemat_materials.add()
            item.name = name
            item.obj_count = mat_counts[name]
            item.selected = old_selection.get(name, False)  # ค่าเริ่มต้นไม่ติ๊กไว้ กันเผลอแทนที่โดยไม่ตั้งใจ

        if mat_counts:
            self.report({'INFO'}, f"พบ {len(mat_counts)} Material จาก {len(targets)} object")
        else:
            self.report({'WARNING'}, "ไม่พบ Material ที่มีหน้าใช้งานจริงเลย (นอกเหนือจาก Material ปลายทาง)")
        return {'FINISHED'}


class REPLACEMAT_OT_select_all(Operator):
    bl_idname = "replacemat.select_all"
    bl_label = "เลือกทั้งหมด"

    def execute(self, context):
        for item in context.scene.replacemat_materials:
            item.selected = True
        return {'FINISHED'}


class REPLACEMAT_OT_select_none(Operator):
    bl_idname = "replacemat.select_none"
    bl_label = "ไม่เลือกเลย"

    def execute(self, context):
        for item in context.scene.replacemat_materials:
            item.selected = False
        return {'FINISHED'}


class REPLACEMAT_OT_select_invert(Operator):
    bl_idname = "replacemat.select_invert"
    bl_label = "สลับ"

    def execute(self, context):
        for item in context.scene.replacemat_materials:
            item.selected = not item.selected
        return {'FINISHED'}


class REPLACEMAT_UL_materials(UIList):
    def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
        row = layout.row(align=True)
        row.prop(item, "selected", text="")
        row.label(text=item.name, icon='MATERIAL')
        row.label(text=f"{item.obj_count} object")


class REPLACEMAT_OT_apply(Operator):
    bl_idname = "replacemat.apply"
    bl_label = "แทนที่ Material"
    bl_description = (
        "แทนที่ Material ที่ติ๊กเลือกไว้ ด้วย Material ปลายทาง ในทุก Object ที่เลือกอยู่ "
        "(สลับ Material Slot โดยตรง ไม่ลบ Material เดิม ไม่แตะเนื้อ Mesh - Ctrl+Z ได้ถ้าพลาด)"
    )
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        scene = context.scene
        replacement_mat = scene.replacemat_target_material
        if replacement_mat is None:
            self.report({'WARNING'}, "กรุณาเลือก Material ปลายทาง (ที่จะใช้แทนที่) ก่อน")
            return {'CANCELLED'}

        chosen_names = {m.name for m in scene.replacemat_materials if m.selected}
        if not chosen_names:
            self.report({'WARNING'}, "กรุณาติ๊กเลือก Material ที่ต้องการแทนที่ก่อน")
            return {'CANCELLED'}

        targets = [o for o in context.selected_objects if o.type == 'MESH']
        if not targets:
            self.report({'WARNING'}, "ไม่มี Mesh Object เป้าหมาย (เลือก Object ในวิวพอร์ตก่อน)")
            return {'CANCELLED'}

        n_slots_replaced = 0
        n_objects_affected = 0
        for obj in targets:
            affected_this_obj = False
            for slot in obj.material_slots:
                if slot.material and slot.material.name in chosen_names:
                    slot.material = replacement_mat
                    n_slots_replaced += 1
                    affected_this_obj = True
            if affected_this_obj:
                n_objects_affected += 1

        self.report(
            {'INFO'},
            f"แทนที่ Material แล้ว {n_slots_replaced} slot ใน {n_objects_affected} object ด้วย '{replacement_mat.name}'",
        )
        bpy.ops.replacemat.scan()  # สแกนใหม่ให้ตรงกับสถานะล่าสุด
        return {'FINISHED'}


# =====================================================================
# Register
# =====================================================================
classes = (
    DecalZoneItem,
    ZoneLinkRule,
    DECALZONE_OT_scan,
    DECALZONE_OT_clear_link_rules,
    DIAMONDEYES_OT_copy_name,
    DIAMONDEYES_OT_copy_diagnostic,
    DIAMONDEYES_OT_switch_tab,
    DIAMONDEYES_OT_select_object,
    DECALZONE_OT_select_all,
    DECALZONE_OT_select_none,
    DECALZONE_OT_select_invert,
    DECALZONE_OT_apply,
    DECALZONE_UL_items,
    DECALZONE_UL_items_no_id,
    DECALZONE_UL_items_invalid,
    MatCleanupItem,
    MATCLEANUP_OT_scan,
    MATCLEANUP_OT_unhide_hidden,
    MATCLEANUP_OT_select_all,
    MATCLEANUP_OT_select_none,
    MATCLEANUP_OT_select_invert,
    MATCLEANUP_OT_apply,
    MATCLEANUP_OT_copy_all,
    MATCLEANUP_UL_items,
    DupCheckItem,
    MergeGroupItem,
    ConditionGroupItem,
    DUPCHECK_OT_scan_condition_groups,
    DUPCHECK_UL_condition_groups,
    DUPCHECK_OT_scan,
    DUPCHECK_OT_select_all,
    DUPCHECK_OT_select_none,
    DUPCHECK_OT_select_invert,
    DUPCHECK_OT_apply,
    DUPCHECK_OT_merge_select_all,
    DUPCHECK_OT_merge_select_none,
    DUPCHECK_OT_merge_apply,
    DUPCHECK_UL_items,
    DUPCHECK_UL_merge_groups,
    UvMapInfoItem,
    UVTOOL_OT_scan,
    UVTOOL_OT_select_all,
    UVTOOL_OT_select_none,
    UVTOOL_OT_select_invert,
    UVTOOL_OT_select_diff,
    UVTOOL_OT_set_active,
    UVTOOL_OT_add_uv,
    UVTOOL_OT_remove_uv,
    UVTOOL_UL_map_items,
    MaterialSelectItem,
    SPLITMAT_OT_scan_materials,
    SPLITMAT_OT_materials_select_all,
    SPLITMAT_OT_materials_select_none,
    SPLITMAT_OT_materials_select_invert,
    SPLITMAT_UL_materials,
    SPLITMAT_OT_split,
    SPLITMAT_OT_merge_back,
    DebrisItem,
    SORTDBR_OT_scan,
    SORTDBR_OT_select_all,
    SORTDBR_OT_select_none,
    SORTDBR_OT_select_invert,
    SORTDBR_UL_items,
    SORTDBR_OT_apply,
    REPLACEMAT_OT_scan,
    REPLACEMAT_OT_select_all,
    REPLACEMAT_OT_select_none,
    REPLACEMAT_OT_select_invert,
    REPLACEMAT_UL_materials,
    REPLACEMAT_OT_apply,
    DIAMONDEYES_PT_panel,
)


# แต่ละหมวดหมู่แสดงเครื่องมือ (tab id) ไหนบ้าง - ใช้กรองปุ่มในแถวที่ 2 ของ panel (draw())
TAB_IDS_BY_CATEGORY = {
    'NAMING': ['DECAL_ZONE', 'DUP_CHECK'],
    'MATERIAL': ['MATERIAL_CLEANUP', 'MAT_SPLIT', 'REPLACE_MAT'],
    'UV': ['UV_TOOL'],
    'ORGANIZE': ['SORT_DBR'],
}


def _on_category_change(self, context):
    """สลับหมวดแล้ว auto-set active_tab ไปตัวแรกของหมวดใหม่ทันที กันเลือกหมวดแล้วไม่มีอะไรขึ้นให้ดู"""
    scene = context.scene
    tabs_in_category = TAB_IDS_BY_CATEGORY.get(scene.diamondeyes_active_category, [])
    if tabs_in_category and scene.diamondeyes_active_tab not in tabs_in_category:
        scene.diamondeyes_active_tab = tabs_in_category[0]


def register():
    load_icons()

    # กันเคส hot-reload ค้าง (เช่น Install ทับ addon เดิมโดยไม่ปิด/restart ก่อน)
    # ลอง unregister class เดิมที่อาจค้างอยู่ก่อน แล้วค่อย register ใหม่ให้สะอาด
    for cls in classes:
        try:
            bpy.utils.unregister_class(cls)
        except (RuntimeError, ValueError):
            pass

    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.decalzone_collection = PointerProperty(
        name="Decal Collection",
        type=bpy.types.Collection,
        description="Collection ที่รวม Decal ที่ต้องการตรวจสอบ (จะสแกนรวม Sub-collection ด้วย)",
    )
    bpy.types.Scene.decalzone_items = CollectionProperty(type=DecalZoneItem)
    bpy.types.Scene.decalzone_items_index = IntProperty(default=0)
    bpy.types.Scene.decalzone_items_index_no_id = IntProperty(default=0)
    bpy.types.Scene.decalzone_items_index_invalid = IntProperty(default=0)
    bpy.types.Scene.decalzone_zone_filter = StringProperty(
        name="กรอง Zone", default="",
        description="พิมพ์ตัวอักษร Zone เช่น A เพื่อกรองเฉพาะ Zone นั้น (เว้นว่าง = แสดงทั้งหมด)",
    )
    bpy.types.Scene.decalzone_only_needs_update = BoolProperty(
        name="แสดงเฉพาะที่ต้องแก้ไข", default=True,
    )
    bpy.types.Scene.decalzone_sort_conditions = BoolProperty(
        name="เรียง Condition ตามตัวอักษร A-Z", default=True,
        description="ปิดถ้าไม่อยากให้เรียงลำดับตัวอักษรใหม่ - จะแค่เติม Zone ที่ขาดต่อท้ายโดยไม่จัดเรียง",
        update=_on_sort_conditions_update,
    )
    bpy.types.Scene.decalzone_link_rules = CollectionProperty(type=ZoneLinkRule)
    bpy.types.Scene.decalzone_show_help = BoolProperty(
        name="ขั้นตอนการใช้งาน", default=False,
    )

    bpy.types.Scene.matcleanup_collection = PointerProperty(
        name="Material Cleanup Collection",
        type=bpy.types.Collection,
        description="Collection ที่ต้องการตรวจ Material ที่ไม่ได้ใช้ (จะสแกนรวม Sub-collection ด้วย)",
    )
    bpy.types.Scene.matcleanup_items = CollectionProperty(type=MatCleanupItem)
    bpy.types.Scene.matcleanup_items_index = IntProperty(default=0)
    bpy.types.Scene.matcleanup_sort_after_cleanup = BoolProperty(
        name="เรียง Material ตามชื่อ A-Z หลังลบ", default=False,
        description="เรียง Material Slot ที่เหลือตามชื่อ A-Z หลังลบตัวที่ไม่ได้ใช้ (ปิดไว้เป็นค่าเริ่มต้นเพราะทำให้ช้าลงถ้ามีหลาย object)",
    )

    bpy.types.Scene.dupcheck_collection = PointerProperty(
        name="Duplicate Checker Collection",
        type=bpy.types.Collection,
        description="Collection ที่ต้องการตรวจชื่อ .001/.002... (จะสแกนรวม Sub-collection ด้วย)",
    )
    bpy.types.Scene.dupcheck_items = CollectionProperty(type=DupCheckItem)
    bpy.types.Scene.dupcheck_items_index = IntProperty(default=0)
    bpy.types.Scene.dupcheck_merge_groups = CollectionProperty(type=MergeGroupItem)
    bpy.types.Scene.dupcheck_merge_groups_index = IntProperty(default=0)
    bpy.types.Scene.dupcheck_condition_groups = CollectionProperty(type=ConditionGroupItem)
    bpy.types.Scene.dupcheck_condition_groups_index = IntProperty(default=0)
    bpy.types.Scene.dupcheck_show_condition_groups = BoolProperty(
        name="Condition Groups Report", default=False,
    )
    bpy.types.Scene.dupcheck_condgroup_lod_filter = StringProperty(
        name="กรอง LOD", default="",
        description="พิมพ์ LOD เช่น LOD0 เพื่อกรองเฉพาะกลุ่มที่อยู่ LOD นั้น (เว้นว่าง = แสดงทุก LOD)",
    )
    bpy.types.Scene.dupcheck_condgroup_only_duplicates = BoolProperty(
        name="แสดงเฉพาะที่ซ้ำกัน", default=False,
        description="แสดงเฉพาะกลุ่มที่มีมากกว่า 1 ชิ้น (ถือเป็นปัญหา) ซ่อนกลุ่มที่ปกติดีไว้",
    )
    bpy.types.Scene.dupcheck_show_help = BoolProperty(
        name="ขั้นตอนการใช้งาน", default=False,
    )

    bpy.types.Scene.uvtool_target_mode = EnumProperty(
        name="ทำกับ",
        items=[
            ('SELECTION', "Object ที่เลือกอยู่", "ใช้ object ที่เลือกในวิวพอร์ตตอนนี้"),
            ('COLLECTION', "Collection", "ใช้ object ทั้งหมดใน Collection ที่เลือก (รวม Sub-collection)"),
        ],
        default='SELECTION',
    )
    bpy.types.Scene.uvtool_collection = PointerProperty(
        name="UV Tool Collection",
        type=bpy.types.Collection,
        description="Collection ที่ต้องการใช้เป็นกลุ่มเป้าหมาย (จะสแกนรวม Sub-collection ด้วย)",
    )
    bpy.types.Scene.uvtool_target_name = StringProperty(
        name="ชื่อ UV Map", default="UVMap0",
        description="ชื่อ UV Map ที่ต้องการตั้งเป็น Active / เพิ่ม / ลบ ให้ Object ที่ติ๊กเลือกไว้",
    )
    bpy.types.Scene.uvtool_map_items = CollectionProperty(type=UvMapInfoItem)
    bpy.types.Scene.uvtool_map_items_index = IntProperty(default=0)

    bpy.types.Scene.splitmat_collection_name = StringProperty(
        name="ชื่อ Collection ปลายทาง", default=DEFAULT_SPLIT_COLLECTION_NAME,
        description="ชื่อ Collection ที่จะเก็บชิ้นที่ Split by Material ออกมา (ใช้ชื่อเดียวกันตอน Merge กลับด้วย)",
    )
    bpy.types.Scene.splitmat_materials = CollectionProperty(type=MaterialSelectItem)
    bpy.types.Scene.splitmat_materials_index = IntProperty(default=0)

    bpy.types.Scene.sortdbr_collection = PointerProperty(
        name="Sort Debris Collection",
        type=bpy.types.Collection,
        description="Collection หลักที่มี Sub-collection ต้องการเรียงลำดับตามชื่อที่ลงท้ายด้วย _dbr_##",
    )
    bpy.types.Scene.sortdbr_direction = EnumProperty(
        name="ลำดับ",
        items=[
            ('ASC', "น้อยไปมาก", "เรียงจากเลข dbr น้อยสุดไปมากสุด"),
            ('DESC', "มากไปน้อย", "เรียงจากเลข dbr มากสุดไปน้อยสุด"),
        ],
        default='ASC',
        update=_on_sortdbr_direction_update,
    )
    bpy.types.Scene.sortdbr_items = CollectionProperty(type=DebrisItem)
    bpy.types.Scene.sortdbr_items_index = IntProperty(default=0)
    bpy.types.Scene.sortdbr_invalid_count = IntProperty(default=0)

    bpy.types.Scene.replacemat_target_material = PointerProperty(
        name="Material ปลายทาง", type=bpy.types.Material,
        description="Material ที่จะใช้แทนที่ Material อื่นที่เลือกไว้",
    )
    bpy.types.Scene.replacemat_materials = CollectionProperty(type=MaterialSelectItem)
    bpy.types.Scene.replacemat_materials_index = IntProperty(default=0)

    bpy.types.Scene.diamondeyes_active_category = EnumProperty(
        name="Category",
        items=[
            ('NAMING', "Naming", "เครื่องมือเกี่ยวกับชื่อ Object และ VIS Condition"),
            ('MATERIAL', "Material", "เครื่องมือเกี่ยวกับ Material"),
            ('UV', "UV", "เครื่องมือเกี่ยวกับ UV Map"),
            ('ORGANIZE', "Organize", "เครื่องมือจัดระเบียบ Collection"),
        ],
        default='NAMING',
        update=_on_category_change,
    )
    bpy.types.Scene.diamondeyes_active_tab = EnumProperty(
        name="Tab",
        items=[
            ('DECAL_ZONE', "Condition Linker", "จัดการ VIS Condition ของ Decal"),
            ('MATERIAL_CLEANUP', "Material Cleanup", "ลบ Material ที่ไม่ได้ใช้"),
            ('DUP_CHECK', "Check & Rename Duplicate", "หา Object ที่ชื่อมี .001/.002... จาก Blender auto-rename"),
            ('UV_TOOL', "UV Selection", "เลือก Face ตาม Material และ/หรือ ตั้ง Active UV Map ตามชื่อ"),
            ('MAT_SPLIT', "Split by Material", "แยก Object ตาม Material เข้า Collection ต่างหาก แล้ว Merge กลับได้"),
            ('SORT_DBR', "Sort Debris", "จัดเรียงลำดับ Sub-collection ตามชื่อที่ลงท้ายด้วย _dbr_## (ไม่เปลี่ยนชื่อใด ๆ)"),
            ('REPLACE_MAT', "Replace Material", "แทนที่ Material ที่เลือกไว้ด้วย Material ปลายทาง ไม่ลบ Material ใด ๆ"),
        ],
        default='DECAL_ZONE',
    )


def unregister():
    del bpy.types.Scene.diamondeyes_active_tab
    del bpy.types.Scene.diamondeyes_active_category

    del bpy.types.Scene.replacemat_materials_index
    del bpy.types.Scene.replacemat_materials
    del bpy.types.Scene.replacemat_target_material

    del bpy.types.Scene.sortdbr_invalid_count
    del bpy.types.Scene.sortdbr_items_index
    del bpy.types.Scene.sortdbr_items
    del bpy.types.Scene.sortdbr_direction
    del bpy.types.Scene.sortdbr_collection

    del bpy.types.Scene.splitmat_materials_index
    del bpy.types.Scene.splitmat_materials
    del bpy.types.Scene.splitmat_collection_name

    del bpy.types.Scene.uvtool_map_items_index
    del bpy.types.Scene.uvtool_map_items
    del bpy.types.Scene.uvtool_target_name
    del bpy.types.Scene.uvtool_collection
    del bpy.types.Scene.uvtool_target_mode

    del bpy.types.Scene.dupcheck_show_help
    del bpy.types.Scene.dupcheck_condgroup_only_duplicates
    del bpy.types.Scene.dupcheck_condgroup_lod_filter
    del bpy.types.Scene.dupcheck_show_condition_groups
    del bpy.types.Scene.dupcheck_condition_groups_index
    del bpy.types.Scene.dupcheck_condition_groups
    del bpy.types.Scene.dupcheck_merge_groups_index
    del bpy.types.Scene.dupcheck_merge_groups
    del bpy.types.Scene.dupcheck_items_index
    del bpy.types.Scene.dupcheck_items
    del bpy.types.Scene.dupcheck_collection

    del bpy.types.Scene.matcleanup_sort_after_cleanup
    del bpy.types.Scene.matcleanup_items_index
    del bpy.types.Scene.matcleanup_items
    del bpy.types.Scene.matcleanup_collection

    del bpy.types.Scene.decalzone_show_help
    del bpy.types.Scene.decalzone_items_index_invalid
    del bpy.types.Scene.decalzone_items_index_no_id
    del bpy.types.Scene.decalzone_link_rules
    del bpy.types.Scene.decalzone_sort_conditions
    del bpy.types.Scene.decalzone_only_needs_update
    del bpy.types.Scene.decalzone_zone_filter
    del bpy.types.Scene.decalzone_items_index
    del bpy.types.Scene.decalzone_items
    del bpy.types.Scene.decalzone_collection

    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)

    unload_icons()


if __name__ == "__main__":
    register()
